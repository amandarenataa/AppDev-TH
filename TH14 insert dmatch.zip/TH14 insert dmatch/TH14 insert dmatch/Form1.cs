﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TH14_insert_dmatch
{
    public partial class F1 : Form
    {
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        string sql;
        DataTable dtMATCH;
        DataTable dtDMATCH;
        DataTable dtTEAMH;
        DataTable dtTEAMA;
        DataTable dtTEAMPILIHAN;
        DataTable dtPlayer;
        DataTable dtInsert;
        public F1()
        {
            InitializeComponent();
        }

        private void F1_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new MySqlConnection("server=localhost;uid=root;pwd=@RagcatsL0ve;database=premier_league");
                conn.Open();
                conn.Close();

                sql = "select `match`.match_id as `Match ID`, `match`.match_date as `Match Date`, team.team_name as `Team Home`, t.team_name as `Team Away`, `match`.goal_home as `Goal Home`, `match`.goal_away as `Goal Away`, `match`.delete as `Delete` from `match` join team on team.team_id = `match`.team_home join team t on t.team_id = `match`.team_away";
                cmd = new MySqlCommand(sql, conn);

                dtMATCH = new DataTable();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtMATCH);

                sql = "select team_name, team_id from team";
                cmd = new MySqlCommand(sql, conn);
                dtTEAMH = new DataTable();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtTEAMH);

                cb_HOME.DataSource = dtTEAMH;
                cb_HOME.ValueMember = "team_id";
                cb_HOME.DisplayMember = "team_name";
                cb_HOME.SelectedIndex = -1;

                sql = "select team_name, team_id from team";
                cmd = new MySqlCommand(sql, conn);
                dtTEAMA = new DataTable();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtTEAMA);

                cb_AWAY.DataSource = dtTEAMA;
                cb_AWAY.ValueMember = "team_id";
                cb_AWAY.DisplayMember = "team_name";
                cb_AWAY.SelectedIndex = -1;


                cb_TYPE.Items.Add("GO");
                cb_TYPE.Items.Add("GP");
                cb_TYPE.Items.Add("GW");
                cb_TYPE.Items.Add("CR");
                cb_TYPE.Items.Add("CY");
                cb_TYPE.Items.Add("PM");

                dtDMATCH = new DataTable();
                dtDMATCH.Columns.Add("Minute");
                dtDMATCH.Columns.Add("Team ID");
                dtDMATCH.Columns.Add("Player ID");
                dtDMATCH.Columns.Add("Type");

                dgv_DMATCH.DataSource = dtDMATCH;

                dtInsert = new DataTable();
                dtInsert.Columns.Add("Minute");
                dtInsert.Columns.Add("Team ID");
                dtInsert.Columns.Add("Player ID");
                dtInsert.Columns.Add("Type");

            }
            catch (Exception ex)
            {
                MessageBox.Show("F1_load " + ex.Message);
            }
        }
        private void cb_HOME_SelectedIndexChanged(object sender, EventArgs e)
        {
            Team();
        }
        private void cb_AWAY_SelectedIndexChanged(object sender, EventArgs e)
        {
            Team();
        }
        public void Team()
        {
            try
            {
                dtTEAMPILIHAN = new DataTable();

                if (cb_HOME.SelectedValue == null || cb_AWAY.SelectedValue == null)
                {
                    return;
                }

                sql = $"select team_id, team_name from team where team_id = '{cb_AWAY.SelectedValue}' or team_id = '{cb_HOME.SelectedValue}';";
                cmd = new MySqlCommand(sql, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtTEAMPILIHAN);

                if (dtTEAMPILIHAN.Rows.Count < 2)
                {
                    MessageBox.Show("jan sama to bang");
                }

                cb_teamINPUT.DataSource = dtTEAMPILIHAN;
                cb_teamINPUT.ValueMember = "team_id";
                cb_teamINPUT.DisplayMember = "team_name";
                cb_teamINPUT.SelectedIndex = -1;

                
            }
            catch (Exception ex)
            {
                MessageBox.Show($"team {ex.Message}");
            }
        }

        private void cb_teamINPUT_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dtPlayer = new DataTable();
                sql = $"select player.player_name, player.team_id from player, team where player.team_id = team.team_id and player.team_id = '{cb_teamINPUT.SelectedValue}';";
                cmd = new MySqlCommand(sql, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtPlayer);

                cb_player.DataSource = dtPlayer;
                cb_player.ValueMember = "team_id";
                cb_player.DisplayMember = "player_name";
                cb_player.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"cb team input {ex.Message}");
            }
        }
        int goalHome = 0;
        int goalAway = 0;
        private void bt_ADD_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_MINUTE.Text == "" || cb_teamINPUT.SelectedIndex == -1 || cb_player.SelectedIndex == -1 || cb_TYPE.SelectedIndex == -1)
                {
                    MessageBox.Show("ERROR!");
                }
                else
                {
                    dtDMATCH.Rows.Add(tb_MINUTE.Text, cb_teamINPUT.Text, cb_player.Text, cb_TYPE.Text);

                    dtInsert.Rows.Add(tb_MINUTE.Text, cb_teamINPUT.SelectedValue, cb_player.SelectedValue, cb_TYPE.Text);

                    if (cb_teamINPUT.SelectedValue == cb_HOME.SelectedValue)
                    {
                        if(cb_TYPE.SelectedItem.ToString() == "GO")
                        {
                            goalHome += 1;
                        }
                        if (cb_TYPE.SelectedItem.ToString() == "GP")
                        {
                            goalHome += 1;
                        }
                        if (cb_TYPE.SelectedItem.ToString() == "GW")
                        {
                            goalAway += 1;
                        }
                    }
                    else
                    {
                        if (cb_TYPE.SelectedItem.ToString() == "GO")
                        {
                            goalAway += 1;
                        }
                        if (cb_TYPE.SelectedItem.ToString() == "GP")
                        {
                            goalAway += 1;
                        }
                        if (cb_TYPE.SelectedItem.ToString() == "GW")
                        {
                            goalHome += 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("bt_add_click " + ex.Message);
            }
        }

        private void bt_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_DMATCH.SelectedRows.Count != 0)
                {
                    int remove = dgv_DMATCH.CurrentCell.RowIndex;
                    dgv_DMATCH.Rows.RemoveAt(remove);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("bt_delete " + ex.Message);
            }
        }

        public DataTable dtDateMax;
        public string dd;
        public string mm;
        public string yyyy;
        public DataTable dtTanggalPilihan;

        private void dtp_match_ValueChanged(object sender, EventArgs e)
        {
            dtDateMax = new DataTable();
            dtTanggalPilihan = new DataTable();
            try
            {
                sql = "select concat(date_format(m.match_date, '%Y'), date_format(m.match_date, '%m'), date_format(m.match_date, '%d')) as matchDate from `match` m order by 1 desc LIMIT 1;";
                cmd = new MySqlCommand(sql, conn);
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtDateMax);

                dd = dtp_match.Value.Day.ToString();
                if (Convert.ToInt32(dd) < 10)
                {
                    dd = $"0{dd}";
                }

                mm = dtp_match.Value.Month.ToString();
                if (Convert.ToInt32(mm) < 10)
                {
                    mm = $"0{mm}";
                }

                yyyy = dtp_match.Value.Year.ToString();

                int pilihanDate = Convert.ToInt32($"{yyyy}{mm}{dd}");
                int maxDate = Convert.ToInt32(dtDateMax.Rows[0][0]);

                if (pilihanDate >= maxDate)
                {
                    sql = $"select match_id from `match` where match_id like '{yyyy}%' order by 1 desc LIMIT 1";
                    cmd = new MySqlCommand(sql, conn);
                    adapter = new MySqlDataAdapter(cmd);
                    adapter.Fill(dtTanggalPilihan);

                    if (dtTanggalPilihan.Rows.Count == 0)
                    {
                        tb_matchID.Text = $"{yyyy}001";
                    }
                    else if (dtTanggalPilihan.Rows.Count == 1)
                    {
                        int cnt = 1;
                        int cntMatch = Convert.ToInt32(dtTanggalPilihan.Rows[0][0]) + cnt;
                        tb_matchID.Text = cntMatch.ToString();
                    }
                }
                else
                {
                    MessageBox.Show("Maks tanggal terakhir kamu input");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"date value {ex.Message}");
            }
        }
        
        private void bt_insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (tb_matchID.Text == "")
                {
                    MessageBox.Show("pilih tgl dulu ya");
                }
                else
                {
                    foreach (DataRow dr in dtInsert.Rows)
                    {
                        MessageBox.Show($"({tb_matchID.Text},{dr[0]},'{dr[1]}','{dr[2]}','{dr[3]}',0)");
                        sql = $"insert into `dmatch` (`match_id`,`minute`,`team_id`,`player_id`,`type`,`delete`) VALUES ({tb_matchID.Text},{dr[0]},'{dr[1]}','{dr[2]}','{dr[3]}',0)";
                        conn.Open();
                        cmd = new MySqlCommand(sql, conn);
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        //MessageBox.Show($"('{tb_matchID}','{yyyy}-{mm}-{dd}','{cb_HOME.SelectedItem}','{cb_AWAY.SelectedItem}',{goalHome},{goalAway},'M002',0)");
                        //sql = $"INSERT INTO `match` (`match_id`,`match_date`,`team_home`,`team_away`,`goal_home`,`goal_away`,`referee_id`,`delete`) VALUES ('{tb_matchID}','{yyyy}-{mm}-{dd}','{cb_HOME.SelectedItem}','{cb_AWAY.SelectedItem}',{goalHome},{goalAway},'M002',0)";
                        //conn.Open();
                        //cmd = new MySqlCommand(sql, conn);
                        //cmd.ExecuteNonQuery();
                        //conn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"insert {ex.Message}");
            }
        }
    }
}
