﻿namespace TH_Week_2__wordle_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_keyQ = new System.Windows.Forms.Button();
            this.btn_keyW = new System.Windows.Forms.Button();
            this.btn_keyE = new System.Windows.Forms.Button();
            this.btn_keyR = new System.Windows.Forms.Button();
            this.btn_keyI = new System.Windows.Forms.Button();
            this.btn_keyU = new System.Windows.Forms.Button();
            this.btn_keyY = new System.Windows.Forms.Button();
            this.btn_keyT = new System.Windows.Forms.Button();
            this.btn_keyP = new System.Windows.Forms.Button();
            this.btn_keyO = new System.Windows.Forms.Button();
            this.btn_keyL = new System.Windows.Forms.Button();
            this.btn_keyK = new System.Windows.Forms.Button();
            this.btn_keyJ = new System.Windows.Forms.Button();
            this.btn_keyH = new System.Windows.Forms.Button();
            this.btn_keyG = new System.Windows.Forms.Button();
            this.btn_keyF = new System.Windows.Forms.Button();
            this.btn_keyD = new System.Windows.Forms.Button();
            this.btn_keyS = new System.Windows.Forms.Button();
            this.btn_keyA = new System.Windows.Forms.Button();
            this.btn_keyM = new System.Windows.Forms.Button();
            this.btn_keyN = new System.Windows.Forms.Button();
            this.btn_keyB = new System.Windows.Forms.Button();
            this.btn_keyV = new System.Windows.Forms.Button();
            this.btn_keyC = new System.Windows.Forms.Button();
            this.btn_keyX = new System.Windows.Forms.Button();
            this.btn_keyZ = new System.Windows.Forms.Button();
            this.lb_blankPertama = new System.Windows.Forms.Label();
            this.lb_blankKedua = new System.Windows.Forms.Label();
            this.lb_blankKetiga = new System.Windows.Forms.Label();
            this.lb_blankKelima = new System.Windows.Forms.Label();
            this.lb_blankKeempat = new System.Windows.Forms.Label();
            this.lb_kataPertama = new System.Windows.Forms.Label();
            this.panel_Keyboard = new System.Windows.Forms.Panel();
            this.txtB_kataPertama = new System.Windows.Forms.TextBox();
            this.txtB_kataKedua = new System.Windows.Forms.TextBox();
            this.lb_kataKedua = new System.Windows.Forms.Label();
            this.txtB_kataKeempat = new System.Windows.Forms.TextBox();
            this.lb_kataKeempat = new System.Windows.Forms.Label();
            this.txtB_kataKetiga = new System.Windows.Forms.TextBox();
            this.lb_kataKetiga = new System.Windows.Forms.Label();
            this.txtB_kataKelima = new System.Windows.Forms.TextBox();
            this.lb_kataKelima = new System.Windows.Forms.Label();
            this.panel_Input = new System.Windows.Forms.Panel();
            this.btn_Done = new System.Windows.Forms.Button();
            this.panel_Keyboard.SuspendLayout();
            this.panel_Input.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_keyQ
            // 
            this.btn_keyQ.Location = new System.Drawing.Point(28, 162);
            this.btn_keyQ.Name = "btn_keyQ";
            this.btn_keyQ.Size = new System.Drawing.Size(93, 77);
            this.btn_keyQ.TabIndex = 0;
            this.btn_keyQ.Text = "Q";
            this.btn_keyQ.UseVisualStyleBackColor = true;
            this.btn_keyQ.Click += new System.EventHandler(this.btn_keyQ_Click);
            // 
            // btn_keyW
            // 
            this.btn_keyW.Location = new System.Drawing.Point(145, 162);
            this.btn_keyW.Name = "btn_keyW";
            this.btn_keyW.Size = new System.Drawing.Size(93, 77);
            this.btn_keyW.TabIndex = 1;
            this.btn_keyW.Text = "W";
            this.btn_keyW.UseVisualStyleBackColor = true;
            this.btn_keyW.Click += new System.EventHandler(this.btn_keyW_Click);
            // 
            // btn_keyE
            // 
            this.btn_keyE.Location = new System.Drawing.Point(267, 162);
            this.btn_keyE.Name = "btn_keyE";
            this.btn_keyE.Size = new System.Drawing.Size(93, 77);
            this.btn_keyE.TabIndex = 2;
            this.btn_keyE.Text = "E";
            this.btn_keyE.UseVisualStyleBackColor = true;
            this.btn_keyE.Click += new System.EventHandler(this.btn_keyE_Click);
            // 
            // btn_keyR
            // 
            this.btn_keyR.Location = new System.Drawing.Point(388, 162);
            this.btn_keyR.Name = "btn_keyR";
            this.btn_keyR.Size = new System.Drawing.Size(93, 77);
            this.btn_keyR.TabIndex = 3;
            this.btn_keyR.Text = "R";
            this.btn_keyR.UseVisualStyleBackColor = true;
            this.btn_keyR.Click += new System.EventHandler(this.btn_keyR_Click);
            // 
            // btn_keyI
            // 
            this.btn_keyI.Location = new System.Drawing.Point(870, 162);
            this.btn_keyI.Name = "btn_keyI";
            this.btn_keyI.Size = new System.Drawing.Size(93, 77);
            this.btn_keyI.TabIndex = 7;
            this.btn_keyI.Text = "I";
            this.btn_keyI.UseVisualStyleBackColor = true;
            this.btn_keyI.Click += new System.EventHandler(this.btn_keyI_Click);
            // 
            // btn_keyU
            // 
            this.btn_keyU.Location = new System.Drawing.Point(749, 162);
            this.btn_keyU.Name = "btn_keyU";
            this.btn_keyU.Size = new System.Drawing.Size(93, 77);
            this.btn_keyU.TabIndex = 6;
            this.btn_keyU.Text = "U";
            this.btn_keyU.UseVisualStyleBackColor = true;
            this.btn_keyU.Click += new System.EventHandler(this.btn_keyU_Click);
            // 
            // btn_keyY
            // 
            this.btn_keyY.Location = new System.Drawing.Point(627, 162);
            this.btn_keyY.Name = "btn_keyY";
            this.btn_keyY.Size = new System.Drawing.Size(93, 77);
            this.btn_keyY.TabIndex = 5;
            this.btn_keyY.Text = "Y";
            this.btn_keyY.UseVisualStyleBackColor = true;
            this.btn_keyY.Click += new System.EventHandler(this.btn_keyY_Click);
            // 
            // btn_keyT
            // 
            this.btn_keyT.Location = new System.Drawing.Point(510, 162);
            this.btn_keyT.Name = "btn_keyT";
            this.btn_keyT.Size = new System.Drawing.Size(93, 77);
            this.btn_keyT.TabIndex = 4;
            this.btn_keyT.Text = "T";
            this.btn_keyT.UseVisualStyleBackColor = true;
            this.btn_keyT.Click += new System.EventHandler(this.btn_keyT_Click);
            // 
            // btn_keyP
            // 
            this.btn_keyP.Location = new System.Drawing.Point(1115, 162);
            this.btn_keyP.Name = "btn_keyP";
            this.btn_keyP.Size = new System.Drawing.Size(93, 77);
            this.btn_keyP.TabIndex = 9;
            this.btn_keyP.Text = "P";
            this.btn_keyP.UseVisualStyleBackColor = true;
            this.btn_keyP.Click += new System.EventHandler(this.btn_keyP_Click);
            // 
            // btn_keyO
            // 
            this.btn_keyO.Location = new System.Drawing.Point(994, 162);
            this.btn_keyO.Name = "btn_keyO";
            this.btn_keyO.Size = new System.Drawing.Size(93, 77);
            this.btn_keyO.TabIndex = 8;
            this.btn_keyO.Text = "O";
            this.btn_keyO.UseVisualStyleBackColor = true;
            this.btn_keyO.Click += new System.EventHandler(this.btn_keyO_Click);
            // 
            // btn_keyL
            // 
            this.btn_keyL.Location = new System.Drawing.Point(1059, 267);
            this.btn_keyL.Name = "btn_keyL";
            this.btn_keyL.Size = new System.Drawing.Size(93, 77);
            this.btn_keyL.TabIndex = 18;
            this.btn_keyL.Text = "L";
            this.btn_keyL.UseVisualStyleBackColor = true;
            this.btn_keyL.Click += new System.EventHandler(this.btn_keyL_Click);
            // 
            // btn_keyK
            // 
            this.btn_keyK.Location = new System.Drawing.Point(935, 267);
            this.btn_keyK.Name = "btn_keyK";
            this.btn_keyK.Size = new System.Drawing.Size(93, 77);
            this.btn_keyK.TabIndex = 17;
            this.btn_keyK.Text = "K";
            this.btn_keyK.UseVisualStyleBackColor = true;
            this.btn_keyK.Click += new System.EventHandler(this.btn_keyK_Click);
            // 
            // btn_keyJ
            // 
            this.btn_keyJ.Location = new System.Drawing.Point(814, 267);
            this.btn_keyJ.Name = "btn_keyJ";
            this.btn_keyJ.Size = new System.Drawing.Size(93, 77);
            this.btn_keyJ.TabIndex = 16;
            this.btn_keyJ.Text = "J";
            this.btn_keyJ.UseVisualStyleBackColor = true;
            this.btn_keyJ.Click += new System.EventHandler(this.btn_keyJ_Click);
            // 
            // btn_keyH
            // 
            this.btn_keyH.Location = new System.Drawing.Point(692, 267);
            this.btn_keyH.Name = "btn_keyH";
            this.btn_keyH.Size = new System.Drawing.Size(93, 77);
            this.btn_keyH.TabIndex = 15;
            this.btn_keyH.Text = "H";
            this.btn_keyH.UseVisualStyleBackColor = true;
            this.btn_keyH.Click += new System.EventHandler(this.btn_keyH_Click);
            // 
            // btn_keyG
            // 
            this.btn_keyG.Location = new System.Drawing.Point(575, 267);
            this.btn_keyG.Name = "btn_keyG";
            this.btn_keyG.Size = new System.Drawing.Size(93, 77);
            this.btn_keyG.TabIndex = 14;
            this.btn_keyG.Text = "G";
            this.btn_keyG.UseVisualStyleBackColor = true;
            this.btn_keyG.Click += new System.EventHandler(this.btn_keyG_Click);
            // 
            // btn_keyF
            // 
            this.btn_keyF.Location = new System.Drawing.Point(453, 267);
            this.btn_keyF.Name = "btn_keyF";
            this.btn_keyF.Size = new System.Drawing.Size(93, 77);
            this.btn_keyF.TabIndex = 13;
            this.btn_keyF.Text = "F";
            this.btn_keyF.UseVisualStyleBackColor = true;
            this.btn_keyF.Click += new System.EventHandler(this.btn_keyF_Click);
            // 
            // btn_keyD
            // 
            this.btn_keyD.Location = new System.Drawing.Point(332, 267);
            this.btn_keyD.Name = "btn_keyD";
            this.btn_keyD.Size = new System.Drawing.Size(93, 77);
            this.btn_keyD.TabIndex = 12;
            this.btn_keyD.Text = "D";
            this.btn_keyD.UseVisualStyleBackColor = true;
            this.btn_keyD.Click += new System.EventHandler(this.btn_keyD_Click);
            // 
            // btn_keyS
            // 
            this.btn_keyS.Location = new System.Drawing.Point(210, 267);
            this.btn_keyS.Name = "btn_keyS";
            this.btn_keyS.Size = new System.Drawing.Size(93, 77);
            this.btn_keyS.TabIndex = 11;
            this.btn_keyS.Text = "S";
            this.btn_keyS.UseVisualStyleBackColor = true;
            this.btn_keyS.Click += new System.EventHandler(this.btn_keyS_Click);
            // 
            // btn_keyA
            // 
            this.btn_keyA.Location = new System.Drawing.Point(93, 267);
            this.btn_keyA.Name = "btn_keyA";
            this.btn_keyA.Size = new System.Drawing.Size(93, 77);
            this.btn_keyA.TabIndex = 10;
            this.btn_keyA.Text = "A";
            this.btn_keyA.UseVisualStyleBackColor = true;
            this.btn_keyA.Click += new System.EventHandler(this.btn_keyA_Click);
            // 
            // btn_keyM
            // 
            this.btn_keyM.Location = new System.Drawing.Point(935, 371);
            this.btn_keyM.Name = "btn_keyM";
            this.btn_keyM.Size = new System.Drawing.Size(93, 77);
            this.btn_keyM.TabIndex = 25;
            this.btn_keyM.Text = "M";
            this.btn_keyM.UseVisualStyleBackColor = true;
            this.btn_keyM.Click += new System.EventHandler(this.btn_keyM_Click);
            // 
            // btn_keyN
            // 
            this.btn_keyN.Location = new System.Drawing.Point(813, 371);
            this.btn_keyN.Name = "btn_keyN";
            this.btn_keyN.Size = new System.Drawing.Size(93, 77);
            this.btn_keyN.TabIndex = 24;
            this.btn_keyN.Text = "N";
            this.btn_keyN.UseVisualStyleBackColor = true;
            this.btn_keyN.Click += new System.EventHandler(this.btn_keyN_Click);
            // 
            // btn_keyB
            // 
            this.btn_keyB.Location = new System.Drawing.Point(696, 371);
            this.btn_keyB.Name = "btn_keyB";
            this.btn_keyB.Size = new System.Drawing.Size(93, 77);
            this.btn_keyB.TabIndex = 23;
            this.btn_keyB.Text = "B";
            this.btn_keyB.UseVisualStyleBackColor = true;
            this.btn_keyB.Click += new System.EventHandler(this.btn_keyB_Click);
            // 
            // btn_keyV
            // 
            this.btn_keyV.Location = new System.Drawing.Point(574, 371);
            this.btn_keyV.Name = "btn_keyV";
            this.btn_keyV.Size = new System.Drawing.Size(93, 77);
            this.btn_keyV.TabIndex = 22;
            this.btn_keyV.Text = "V";
            this.btn_keyV.UseVisualStyleBackColor = true;
            this.btn_keyV.Click += new System.EventHandler(this.btn_keyV_Click);
            // 
            // btn_keyC
            // 
            this.btn_keyC.Location = new System.Drawing.Point(453, 371);
            this.btn_keyC.Name = "btn_keyC";
            this.btn_keyC.Size = new System.Drawing.Size(93, 77);
            this.btn_keyC.TabIndex = 21;
            this.btn_keyC.Text = "C";
            this.btn_keyC.UseVisualStyleBackColor = true;
            this.btn_keyC.Click += new System.EventHandler(this.btn_keyC_Click);
            // 
            // btn_keyX
            // 
            this.btn_keyX.Location = new System.Drawing.Point(332, 371);
            this.btn_keyX.Name = "btn_keyX";
            this.btn_keyX.Size = new System.Drawing.Size(93, 77);
            this.btn_keyX.TabIndex = 20;
            this.btn_keyX.Text = "X";
            this.btn_keyX.UseVisualStyleBackColor = true;
            this.btn_keyX.Click += new System.EventHandler(this.btn_keyX_Click);
            // 
            // btn_keyZ
            // 
            this.btn_keyZ.Location = new System.Drawing.Point(214, 371);
            this.btn_keyZ.Name = "btn_keyZ";
            this.btn_keyZ.Size = new System.Drawing.Size(93, 77);
            this.btn_keyZ.TabIndex = 19;
            this.btn_keyZ.Text = "Z";
            this.btn_keyZ.UseVisualStyleBackColor = true;
            this.btn_keyZ.Click += new System.EventHandler(this.btn_keyZ_Click);
            // 
            // lb_blankPertama
            // 
            this.lb_blankPertama.AutoSize = true;
            this.lb_blankPertama.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blankPertama.Location = new System.Drawing.Point(328, 11);
            this.lb_blankPertama.Name = "lb_blankPertama";
            this.lb_blankPertama.Size = new System.Drawing.Size(98, 108);
            this.lb_blankPertama.TabIndex = 26;
            this.lb_blankPertama.Text = "_";
            // 
            // lb_blankKedua
            // 
            this.lb_blankKedua.AutoSize = true;
            this.lb_blankKedua.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blankKedua.Location = new System.Drawing.Point(449, 11);
            this.lb_blankKedua.Name = "lb_blankKedua";
            this.lb_blankKedua.Size = new System.Drawing.Size(98, 108);
            this.lb_blankKedua.TabIndex = 27;
            this.lb_blankKedua.Text = "_";
            // 
            // lb_blankKetiga
            // 
            this.lb_blankKetiga.AutoSize = true;
            this.lb_blankKetiga.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blankKetiga.Location = new System.Drawing.Point(570, 11);
            this.lb_blankKetiga.Name = "lb_blankKetiga";
            this.lb_blankKetiga.Size = new System.Drawing.Size(98, 108);
            this.lb_blankKetiga.TabIndex = 28;
            this.lb_blankKetiga.Text = "_";
            // 
            // lb_blankKelima
            // 
            this.lb_blankKelima.AutoSize = true;
            this.lb_blankKelima.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blankKelima.Location = new System.Drawing.Point(809, 11);
            this.lb_blankKelima.Name = "lb_blankKelima";
            this.lb_blankKelima.Size = new System.Drawing.Size(98, 108);
            this.lb_blankKelima.TabIndex = 30;
            this.lb_blankKelima.Text = "_";
            // 
            // lb_blankKeempat
            // 
            this.lb_blankKeempat.AutoSize = true;
            this.lb_blankKeempat.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_blankKeempat.Location = new System.Drawing.Point(688, 11);
            this.lb_blankKeempat.Name = "lb_blankKeempat";
            this.lb_blankKeempat.Size = new System.Drawing.Size(98, 108);
            this.lb_blankKeempat.TabIndex = 29;
            this.lb_blankKeempat.Text = "_";
            // 
            // lb_kataPertama
            // 
            this.lb_kataPertama.AutoSize = true;
            this.lb_kataPertama.Location = new System.Drawing.Point(12, 26);
            this.lb_kataPertama.Name = "lb_kataPertama";
            this.lb_kataPertama.Size = new System.Drawing.Size(74, 25);
            this.lb_kataPertama.TabIndex = 31;
            this.lb_kataPertama.Text = "Kata 1";
            // 
            // panel_Keyboard
            // 
            this.panel_Keyboard.Controls.Add(this.btn_keyT);
            this.panel_Keyboard.Controls.Add(this.lb_blankKelima);
            this.panel_Keyboard.Controls.Add(this.btn_keyQ);
            this.panel_Keyboard.Controls.Add(this.lb_blankKeempat);
            this.panel_Keyboard.Controls.Add(this.btn_keyW);
            this.panel_Keyboard.Controls.Add(this.lb_blankKetiga);
            this.panel_Keyboard.Controls.Add(this.btn_keyE);
            this.panel_Keyboard.Controls.Add(this.lb_blankKedua);
            this.panel_Keyboard.Controls.Add(this.btn_keyR);
            this.panel_Keyboard.Controls.Add(this.lb_blankPertama);
            this.panel_Keyboard.Controls.Add(this.btn_keyY);
            this.panel_Keyboard.Controls.Add(this.btn_keyM);
            this.panel_Keyboard.Controls.Add(this.btn_keyU);
            this.panel_Keyboard.Controls.Add(this.btn_keyN);
            this.panel_Keyboard.Controls.Add(this.btn_keyI);
            this.panel_Keyboard.Controls.Add(this.btn_keyB);
            this.panel_Keyboard.Controls.Add(this.btn_keyO);
            this.panel_Keyboard.Controls.Add(this.btn_keyV);
            this.panel_Keyboard.Controls.Add(this.btn_keyP);
            this.panel_Keyboard.Controls.Add(this.btn_keyC);
            this.panel_Keyboard.Controls.Add(this.btn_keyA);
            this.panel_Keyboard.Controls.Add(this.btn_keyX);
            this.panel_Keyboard.Controls.Add(this.btn_keyS);
            this.panel_Keyboard.Controls.Add(this.btn_keyZ);
            this.panel_Keyboard.Controls.Add(this.btn_keyD);
            this.panel_Keyboard.Controls.Add(this.btn_keyL);
            this.panel_Keyboard.Controls.Add(this.btn_keyF);
            this.panel_Keyboard.Controls.Add(this.btn_keyK);
            this.panel_Keyboard.Controls.Add(this.btn_keyG);
            this.panel_Keyboard.Controls.Add(this.btn_keyJ);
            this.panel_Keyboard.Controls.Add(this.btn_keyH);
            this.panel_Keyboard.Location = new System.Drawing.Point(10, 310);
            this.panel_Keyboard.Name = "panel_Keyboard";
            this.panel_Keyboard.Size = new System.Drawing.Size(1231, 461);
            this.panel_Keyboard.TabIndex = 32;
            // 
            // txtB_kataPertama
            // 
            this.txtB_kataPertama.Location = new System.Drawing.Point(107, 23);
            this.txtB_kataPertama.Name = "txtB_kataPertama";
            this.txtB_kataPertama.Size = new System.Drawing.Size(149, 31);
            this.txtB_kataPertama.TabIndex = 33;
            // 
            // txtB_kataKedua
            // 
            this.txtB_kataKedua.Location = new System.Drawing.Point(107, 72);
            this.txtB_kataKedua.Name = "txtB_kataKedua";
            this.txtB_kataKedua.Size = new System.Drawing.Size(149, 31);
            this.txtB_kataKedua.TabIndex = 35;
            // 
            // lb_kataKedua
            // 
            this.lb_kataKedua.AutoSize = true;
            this.lb_kataKedua.Location = new System.Drawing.Point(12, 75);
            this.lb_kataKedua.Name = "lb_kataKedua";
            this.lb_kataKedua.Size = new System.Drawing.Size(74, 25);
            this.lb_kataKedua.TabIndex = 34;
            this.lb_kataKedua.Text = "Kata 2";
            // 
            // txtB_kataKeempat
            // 
            this.txtB_kataKeempat.Location = new System.Drawing.Point(107, 174);
            this.txtB_kataKeempat.Name = "txtB_kataKeempat";
            this.txtB_kataKeempat.Size = new System.Drawing.Size(149, 31);
            this.txtB_kataKeempat.TabIndex = 39;
            // 
            // lb_kataKeempat
            // 
            this.lb_kataKeempat.AutoSize = true;
            this.lb_kataKeempat.Location = new System.Drawing.Point(12, 177);
            this.lb_kataKeempat.Name = "lb_kataKeempat";
            this.lb_kataKeempat.Size = new System.Drawing.Size(74, 25);
            this.lb_kataKeempat.TabIndex = 38;
            this.lb_kataKeempat.Text = "Kata 4";
            // 
            // txtB_kataKetiga
            // 
            this.txtB_kataKetiga.Location = new System.Drawing.Point(107, 125);
            this.txtB_kataKetiga.Name = "txtB_kataKetiga";
            this.txtB_kataKetiga.Size = new System.Drawing.Size(149, 31);
            this.txtB_kataKetiga.TabIndex = 37;
            // 
            // lb_kataKetiga
            // 
            this.lb_kataKetiga.AutoSize = true;
            this.lb_kataKetiga.Location = new System.Drawing.Point(12, 128);
            this.lb_kataKetiga.Name = "lb_kataKetiga";
            this.lb_kataKetiga.Size = new System.Drawing.Size(74, 25);
            this.lb_kataKetiga.TabIndex = 36;
            this.lb_kataKetiga.Text = "Kata 3";
            // 
            // txtB_kataKelima
            // 
            this.txtB_kataKelima.Location = new System.Drawing.Point(107, 223);
            this.txtB_kataKelima.Name = "txtB_kataKelima";
            this.txtB_kataKelima.Size = new System.Drawing.Size(149, 31);
            this.txtB_kataKelima.TabIndex = 41;
            // 
            // lb_kataKelima
            // 
            this.lb_kataKelima.AutoSize = true;
            this.lb_kataKelima.Location = new System.Drawing.Point(12, 226);
            this.lb_kataKelima.Name = "lb_kataKelima";
            this.lb_kataKelima.Size = new System.Drawing.Size(74, 25);
            this.lb_kataKelima.TabIndex = 40;
            this.lb_kataKelima.Text = "Kata 5";
            // 
            // panel_Input
            // 
            this.panel_Input.Controls.Add(this.btn_Done);
            this.panel_Input.Controls.Add(this.txtB_kataKelima);
            this.panel_Input.Controls.Add(this.lb_kataPertama);
            this.panel_Input.Controls.Add(this.lb_kataKelima);
            this.panel_Input.Controls.Add(this.txtB_kataPertama);
            this.panel_Input.Controls.Add(this.txtB_kataKeempat);
            this.panel_Input.Controls.Add(this.lb_kataKedua);
            this.panel_Input.Controls.Add(this.lb_kataKeempat);
            this.panel_Input.Controls.Add(this.txtB_kataKedua);
            this.panel_Input.Controls.Add(this.txtB_kataKetiga);
            this.panel_Input.Controls.Add(this.lb_kataKetiga);
            this.panel_Input.Location = new System.Drawing.Point(12, 12);
            this.panel_Input.Name = "panel_Input";
            this.panel_Input.Size = new System.Drawing.Size(437, 275);
            this.panel_Input.TabIndex = 42;
            // 
            // btn_Done
            // 
            this.btn_Done.Location = new System.Drawing.Point(311, 215);
            this.btn_Done.Name = "btn_Done";
            this.btn_Done.Size = new System.Drawing.Size(115, 47);
            this.btn_Done.TabIndex = 43;
            this.btn_Done.Text = "Done";
            this.btn_Done.UseVisualStyleBackColor = true;
            this.btn_Done.Click += new System.EventHandler(this.btn_Done_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1253, 783);
            this.Controls.Add(this.panel_Input);
            this.Controls.Add(this.panel_Keyboard);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_Keyboard.ResumeLayout(false);
            this.panel_Keyboard.PerformLayout();
            this.panel_Input.ResumeLayout(false);
            this.panel_Input.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_keyQ;
        private System.Windows.Forms.Button btn_keyW;
        private System.Windows.Forms.Button btn_keyE;
        private System.Windows.Forms.Button btn_keyR;
        private System.Windows.Forms.Button btn_keyI;
        private System.Windows.Forms.Button btn_keyU;
        private System.Windows.Forms.Button btn_keyY;
        private System.Windows.Forms.Button btn_keyT;
        private System.Windows.Forms.Button btn_keyP;
        private System.Windows.Forms.Button btn_keyO;
        private System.Windows.Forms.Button btn_keyL;
        private System.Windows.Forms.Button btn_keyK;
        private System.Windows.Forms.Button btn_keyJ;
        private System.Windows.Forms.Button btn_keyH;
        private System.Windows.Forms.Button btn_keyG;
        private System.Windows.Forms.Button btn_keyF;
        private System.Windows.Forms.Button btn_keyD;
        private System.Windows.Forms.Button btn_keyS;
        private System.Windows.Forms.Button btn_keyA;
        private System.Windows.Forms.Button btn_keyM;
        private System.Windows.Forms.Button btn_keyN;
        private System.Windows.Forms.Button btn_keyB;
        private System.Windows.Forms.Button btn_keyV;
        private System.Windows.Forms.Button btn_keyC;
        private System.Windows.Forms.Button btn_keyX;
        private System.Windows.Forms.Button btn_keyZ;
        private System.Windows.Forms.Label lb_blankPertama;
        private System.Windows.Forms.Label lb_blankKedua;
        private System.Windows.Forms.Label lb_blankKetiga;
        private System.Windows.Forms.Label lb_blankKelima;
        private System.Windows.Forms.Label lb_blankKeempat;
        private System.Windows.Forms.Label lb_kataPertama;
        private System.Windows.Forms.Panel panel_Keyboard;
        private System.Windows.Forms.TextBox txtB_kataPertama;
        private System.Windows.Forms.TextBox txtB_kataKedua;
        private System.Windows.Forms.Label lb_kataKedua;
        private System.Windows.Forms.TextBox txtB_kataKeempat;
        private System.Windows.Forms.Label lb_kataKeempat;
        private System.Windows.Forms.TextBox txtB_kataKetiga;
        private System.Windows.Forms.Label lb_kataKetiga;
        private System.Windows.Forms.TextBox txtB_kataKelima;
        private System.Windows.Forms.Label lb_kataKelima;
        private System.Windows.Forms.Panel panel_Input;
        private System.Windows.Forms.Button btn_Done;
    }
}

