﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Week_2__wordle_
{
    public partial class Form1 : Form
    {
        public List<string> kataDahOK = new List<string>();
        public int randomKata;
        public string Kata;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            panel_Keyboard.Visible = false;
        }
        private void btn_Done_Click(object sender, EventArgs e)
        {
            int count = 0;

            List<string> kata = new List<string>();

            foreach (char k in txtB_kataPertama.Text)
            {
                count++;
            }
            if (count != 5)
            {
                MessageBox.Show("ERROR BANG 1");
            }
            else
            {
                count = 0;
                txtB_kataPertama.Text.ToLower();
                kata.Add(txtB_kataPertama.Text);

                foreach (char k in txtB_kataKedua.Text)
                {
                    count++;
                }
                if (kata.Contains(txtB_kataKedua.Text) || count != 5)
                {
                    MessageBox.Show("ERROR BANG 2");
                }
                else
                {
                    count = 0;
                    txtB_kataKedua.Text.ToLower();
                    kata.Add(txtB_kataKedua.Text);

                    foreach (char k in txtB_kataKetiga.Text)
                    {
                        count++;
                    }
                    if (kata.Contains(txtB_kataKetiga.Text) || count != 5)
                    {
                        MessageBox.Show("ERROR BANG 3");
                    }
                    else
                    {
                        count = 0;
                        txtB_kataKetiga.Text.ToLower();
                        kata.Add(txtB_kataKetiga.Text);

                        foreach (char k in txtB_kataKeempat.Text)
                        {
                            count++;
                        }
                        if (kata.Contains(txtB_kataKeempat.Text) || count != 5)
                        {
                            MessageBox.Show("ERROR BANG 4");
                        }
                        else
                        {
                            count = 0;
                            txtB_kataKeempat.Text.ToLower();
                            kata.Add(txtB_kataKeempat.Text);

                            foreach (char k in txtB_kataKelima.Text)
                            {
                                count++;
                            }
                            if (kata.Contains(txtB_kataKelima.Text) || count != 5)
                            {
                                MessageBox.Show("ERROR BANG 5");
                            }
                            else
                            {
                                txtB_kataKelima.Text.ToLower();
                                kata.Add(txtB_kataKelima.Text);
                                panel_Input.Visible = false;
                                panel_Keyboard.Visible = true;
                                foreach ( string k in kata)
                                {
                                    kataDahOK.Add(k);
                                }
                                randomKata = new Random().Next(5);
                                Kata = kataDahOK[randomKata];
                            }
                        }
                    }
                }
            }
        }
    
        private void btn_keyQ_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("q"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'q')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "Q";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "Q";
                        }
                        if(count == 2)
                        {
                            lb_blankKetiga.Text = "Q";
                        }
                        if(count == 3)
                        {
                            lb_blankKeempat.Text = "Q";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "Q";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyW_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("w"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'w')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "W";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "W";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "W";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "W";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "W";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyE_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("e"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'e')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "E";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "E";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "E";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "E";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "E";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyR_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("r"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'r')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "R";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "R";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "R";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "R";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "R";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyT_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("t"))
            {
                foreach (char k in Kata)
                {
                    if (k == 't')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "T";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "T";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "T";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "T";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "T";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyY_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("y"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'y')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "Y";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "Y";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "Y";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "Y";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "Y";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyU_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("u"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'u')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "U";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "U";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "U";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "U";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "U";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyI_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("i"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'i')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "I";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "I";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "I";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "I";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "I";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyO_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("o"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'o')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "O";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "O";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "O";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "O";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "O";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyP_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("p"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'p')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "P";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "P";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "P";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "P";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "P";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyA_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("a"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'a')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "A";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "A";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "A";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "A";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "A";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyS_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("s"))
            {
                foreach (char k in Kata)
                {
                    if (k == 's')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "S";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "S";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "S";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "S";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "S";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyD_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("d"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'd')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "D";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "D";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "D";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "D";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "D";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyF_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("f"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'f')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "F";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "F";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "F";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "F";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "F";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyG_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("g"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'g')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "G";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "G";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "G";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "G";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "G";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyH_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("h"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'h')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "H";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "H";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "H";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "H";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "H";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyJ_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("j"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'j')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "J";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "J";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "J";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "J";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "J";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyK_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("k"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'k')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "K";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "K";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "K";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "K";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "K";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyL_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("l"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'l')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "L";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "L";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "L";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "L";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "L";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyZ_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("z"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'z')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "Z";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "Z";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "Z";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "Z";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "Z";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyX_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("x"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'x')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "X";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "X";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "X";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "X";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "X";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyC_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("c"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'c')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "C";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "C";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "C";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "C";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "C";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyV_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("v"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'v')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "V";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "V";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "V";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "V";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "V";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyB_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("b"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'b')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "B";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "B";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "B";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "B";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "B";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyN_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("n"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'n')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "N";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "N";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "N";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "N";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "N";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }

        private void btn_keyM_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (Kata.Contains("m"))
            {
                foreach (char k in Kata)
                {
                    if (k == 'm')
                    {
                        if (count == 0)
                        {
                            lb_blankPertama.Text = "M";
                        }
                        if (count == 1)
                        {
                            lb_blankKedua.Text = "M";
                        }
                        if (count == 2)
                        {
                            lb_blankKetiga.Text = "M";
                        }
                        if (count == 3)
                        {
                            lb_blankKeempat.Text = "M";
                        }
                        if (count == 4)
                        {
                            lb_blankKelima.Text = "M";
                        }
                    }
                    count++;
                }
            }
            if (lb_blankPertama.Text != "_" && lb_blankKedua.Text != "_" && lb_blankKetiga.Text != "_" && lb_blankKeempat.Text != "_" && lb_blankKelima.Text != "_")
            {
                MessageBox.Show("YOU WIN");
            }
        }
    }
}
