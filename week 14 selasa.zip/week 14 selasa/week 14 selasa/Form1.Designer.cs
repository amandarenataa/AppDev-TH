﻿namespace week_14_selasa
{
    partial class F1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_matchID = new System.Windows.Forms.Label();
            this.lb_MatchDATE = new System.Windows.Forms.Label();
            this.lb_TeamAWAY = new System.Windows.Forms.Label();
            this.lb_teamHOME = new System.Windows.Forms.Label();
            this.dgv_DMATCH = new System.Windows.Forms.DataGridView();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.cb_HOME = new System.Windows.Forms.ComboBox();
            this.cb_AWAY = new System.Windows.Forms.ComboBox();
            this.dtp_match = new System.Windows.Forms.DateTimePicker();
            this.tb_MINUTE = new System.Windows.Forms.TextBox();
            this.lb_minute = new System.Windows.Forms.Label();
            this.cb_teamINPUT = new System.Windows.Forms.ComboBox();
            this.lb_Team = new System.Windows.Forms.Label();
            this.cb_player = new System.Windows.Forms.ComboBox();
            this.lb_player = new System.Windows.Forms.Label();
            this.cb_TYPE = new System.Windows.Forms.ComboBox();
            this.lb_type = new System.Windows.Forms.Label();
            this.bt_ADD = new System.Windows.Forms.Button();
            this.bt_Delete = new System.Windows.Forms.Button();
            this.bt_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DMATCH)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(90, 60);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(97, 25);
            this.lb_matchID.TabIndex = 0;
            this.lb_matchID.Text = "Match ID";
            // 
            // lb_MatchDATE
            // 
            this.lb_MatchDATE.AutoSize = true;
            this.lb_MatchDATE.Location = new System.Drawing.Point(905, 60);
            this.lb_MatchDATE.Name = "lb_MatchDATE";
            this.lb_MatchDATE.Size = new System.Drawing.Size(122, 25);
            this.lb_MatchDATE.TabIndex = 1;
            this.lb_MatchDATE.Text = "Match Date";
            // 
            // lb_TeamAWAY
            // 
            this.lb_TeamAWAY.AutoSize = true;
            this.lb_TeamAWAY.Location = new System.Drawing.Point(905, 124);
            this.lb_TeamAWAY.Name = "lb_TeamAWAY";
            this.lb_TeamAWAY.Size = new System.Drawing.Size(124, 25);
            this.lb_TeamAWAY.TabIndex = 3;
            this.lb_TeamAWAY.Text = "Team Away";
            // 
            // lb_teamHOME
            // 
            this.lb_teamHOME.AutoSize = true;
            this.lb_teamHOME.Location = new System.Drawing.Point(90, 124);
            this.lb_teamHOME.Name = "lb_teamHOME";
            this.lb_teamHOME.Size = new System.Drawing.Size(128, 25);
            this.lb_teamHOME.TabIndex = 2;
            this.lb_teamHOME.Text = "Team Home";
            // 
            // dgv_DMATCH
            // 
            this.dgv_DMATCH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_DMATCH.Location = new System.Drawing.Point(33, 244);
            this.dgv_DMATCH.Name = "dgv_DMATCH";
            this.dgv_DMATCH.RowHeadersWidth = 82;
            this.dgv_DMATCH.RowTemplate.Height = 33;
            this.dgv_DMATCH.Size = new System.Drawing.Size(993, 612);
            this.dgv_DMATCH.TabIndex = 4;
            this.dgv_DMATCH.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_DMATCH_CellContentClick);
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(284, 60);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(255, 31);
            this.tb_matchID.TabIndex = 5;
            // 
            // cb_HOME
            // 
            this.cb_HOME.FormattingEnabled = true;
            this.cb_HOME.Location = new System.Drawing.Point(284, 116);
            this.cb_HOME.Name = "cb_HOME";
            this.cb_HOME.Size = new System.Drawing.Size(255, 33);
            this.cb_HOME.TabIndex = 6;
            this.cb_HOME.SelectedIndexChanged += new System.EventHandler(this.cb_HOME_SelectedIndexChanged);
            // 
            // cb_AWAY
            // 
            this.cb_AWAY.FormattingEnabled = true;
            this.cb_AWAY.Location = new System.Drawing.Point(1102, 116);
            this.cb_AWAY.Name = "cb_AWAY";
            this.cb_AWAY.Size = new System.Drawing.Size(255, 33);
            this.cb_AWAY.TabIndex = 7;
            this.cb_AWAY.SelectedIndexChanged += new System.EventHandler(this.cb_AWAY_SelectedIndexChanged);
            // 
            // dtp_match
            // 
            this.dtp_match.Location = new System.Drawing.Point(1102, 60);
            this.dtp_match.Name = "dtp_match";
            this.dtp_match.Size = new System.Drawing.Size(402, 31);
            this.dtp_match.TabIndex = 8;
            this.dtp_match.ValueChanged += new System.EventHandler(this.dtp_match_ValueChanged);
            // 
            // tb_MINUTE
            // 
            this.tb_MINUTE.Location = new System.Drawing.Point(1309, 278);
            this.tb_MINUTE.Name = "tb_MINUTE";
            this.tb_MINUTE.Size = new System.Drawing.Size(255, 31);
            this.tb_MINUTE.TabIndex = 10;
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(1115, 278);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(77, 25);
            this.lb_minute.TabIndex = 9;
            this.lb_minute.Text = "Minute";
            // 
            // cb_teamINPUT
            // 
            this.cb_teamINPUT.FormattingEnabled = true;
            this.cb_teamINPUT.Location = new System.Drawing.Point(1309, 335);
            this.cb_teamINPUT.Name = "cb_teamINPUT";
            this.cb_teamINPUT.Size = new System.Drawing.Size(255, 33);
            this.cb_teamINPUT.TabIndex = 12;
            this.cb_teamINPUT.SelectedIndexChanged += new System.EventHandler(this.cb_teamINPUT_SelectedIndexChanged);
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(1115, 343);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(66, 25);
            this.lb_Team.TabIndex = 11;
            this.lb_Team.Text = "Team";
            // 
            // cb_player
            // 
            this.cb_player.FormattingEnabled = true;
            this.cb_player.Location = new System.Drawing.Point(1309, 392);
            this.cb_player.Name = "cb_player";
            this.cb_player.Size = new System.Drawing.Size(255, 33);
            this.cb_player.TabIndex = 14;
            this.cb_player.SelectedIndexChanged += new System.EventHandler(this.cb_player_SelectedIndexChanged);
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(1115, 400);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(73, 25);
            this.lb_player.TabIndex = 13;
            this.lb_player.Text = "Player";
            // 
            // cb_TYPE
            // 
            this.cb_TYPE.FormattingEnabled = true;
            this.cb_TYPE.Location = new System.Drawing.Point(1309, 453);
            this.cb_TYPE.Name = "cb_TYPE";
            this.cb_TYPE.Size = new System.Drawing.Size(255, 33);
            this.cb_TYPE.TabIndex = 16;
            this.cb_TYPE.SelectedIndexChanged += new System.EventHandler(this.cb_TYPE_SelectedIndexChanged);
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(1115, 461);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(60, 25);
            this.lb_type.TabIndex = 15;
            this.lb_type.Text = "Type";
            // 
            // bt_ADD
            // 
            this.bt_ADD.Location = new System.Drawing.Point(1195, 573);
            this.bt_ADD.Name = "bt_ADD";
            this.bt_ADD.Size = new System.Drawing.Size(161, 47);
            this.bt_ADD.TabIndex = 17;
            this.bt_ADD.Text = "Add";
            this.bt_ADD.UseVisualStyleBackColor = true;
            this.bt_ADD.Click += new System.EventHandler(this.bt_ADD_Click);
            // 
            // bt_Delete
            // 
            this.bt_Delete.Location = new System.Drawing.Point(1383, 573);
            this.bt_Delete.Name = "bt_Delete";
            this.bt_Delete.Size = new System.Drawing.Size(161, 47);
            this.bt_Delete.TabIndex = 18;
            this.bt_Delete.Text = "Delete";
            this.bt_Delete.UseVisualStyleBackColor = true;
            this.bt_Delete.Click += new System.EventHandler(this.bt_Delete_Click);
            // 
            // bt_insert
            // 
            this.bt_insert.Location = new System.Drawing.Point(1120, 809);
            this.bt_insert.Name = "bt_insert";
            this.bt_insert.Size = new System.Drawing.Size(512, 47);
            this.bt_insert.TabIndex = 19;
            this.bt_insert.Text = "Insert";
            this.bt_insert.UseVisualStyleBackColor = true;
            // 
            // F1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1770, 958);
            this.Controls.Add(this.bt_insert);
            this.Controls.Add(this.bt_Delete);
            this.Controls.Add(this.bt_ADD);
            this.Controls.Add(this.cb_TYPE);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.cb_player);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.cb_teamINPUT);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.tb_MINUTE);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.dtp_match);
            this.Controls.Add(this.cb_AWAY);
            this.Controls.Add(this.cb_HOME);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.dgv_DMATCH);
            this.Controls.Add(this.lb_TeamAWAY);
            this.Controls.Add(this.lb_teamHOME);
            this.Controls.Add(this.lb_MatchDATE);
            this.Controls.Add(this.lb_matchID);
            this.Name = "F1";
            this.Text = "F1";
            this.Load += new System.EventHandler(this.F1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_DMATCH)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_matchID;
        private System.Windows.Forms.Label lb_MatchDATE;
        private System.Windows.Forms.Label lb_TeamAWAY;
        private System.Windows.Forms.Label lb_teamHOME;
        private System.Windows.Forms.DataGridView dgv_DMATCH;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.ComboBox cb_HOME;
        private System.Windows.Forms.ComboBox cb_AWAY;
        private System.Windows.Forms.DateTimePicker dtp_match;
        private System.Windows.Forms.TextBox tb_MINUTE;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.ComboBox cb_teamINPUT;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.ComboBox cb_player;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.ComboBox cb_TYPE;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.Button bt_ADD;
        private System.Windows.Forms.Button bt_Delete;
        private System.Windows.Forms.Button bt_insert;
    }
}

