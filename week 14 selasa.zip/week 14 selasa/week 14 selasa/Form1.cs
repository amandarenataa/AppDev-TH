﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace week_14_selasa
{
    public partial class F1 : Form
    {
        MySqlConnection conn;
        MySqlCommand cmd;
        MySqlDataAdapter adapter;
        string sql;
        DataTable dtMATCH;
        DataTable dtDMATCH;
        DataTable dtTEAM;
        DataTable dtPlayer;

        public F1()
        {
            InitializeComponent();
        }

        private void F1_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
                conn.Open();
                conn.Close();

                sql = "select `match`.match_id as `Match ID`, `match`.match_date as `Match Date`, team.team_name as `Team Home`, t.team_name as `Team Away`, `match`.goal_home as `Goal Home`, `match`.goal_away as `Goal Away`, `match`.delete as `Delete` from `match` join team on team.team_id = `match`.team_home join team t on t.team_id = `match`.team_away";
                cmd = new MySqlCommand(sql, conn);

                dtMATCH = new DataTable();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtMATCH);

                sql = "select team_name from team";
                cmd = new MySqlCommand(sql, conn);

                dtTEAM = new DataTable();
                adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dtTEAM);

                foreach (DataRow row in dtTEAM.Rows)
                {
                    cb_AWAY.Items.Add(row[0]);
                    cb_HOME.Items.Add(row[0]);
                }

                cb_TYPE.Items.Add("GO");
                cb_TYPE.Items.Add("GP");
                cb_TYPE.Items.Add("GW");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            /*
            sql = "";
            cmd = new MySqlCommand(sql, conn);

            dtDMATCH = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDMATCH);
            */

        }
        int PilihanHome;
        bool HomeTerpilih;
        private void cb_HOME_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PilihanHome = cb_HOME.SelectedIndex;
                HomeTerpilih = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        int PilihanAway;
        string TeamHome;
        string TeamAway;
        string MatchID;

        private void cb_AWAY_SelectedIndexChanged(object sender, EventArgs e)
        {
            try 
            {
                if (HomeTerpilih == false)
                {
                    MessageBox.Show("Please Pick The Team Home First");
                    cb_AWAY.SelectedIndex = -1;
                }
                else
                {
                    if (PilihanHome == cb_AWAY.SelectedIndex)
                    {
                        MessageBox.Show("You Picked The Same Team As Team Home");
                        cb_AWAY.SelectedIndex = -1;
                    }
                    else
                    {
                        PilihanAway = cb_AWAY.SelectedIndex;

                        int index = 0;
                        foreach (DataRow row in dtTEAM.Rows)
                        {
                            if (PilihanHome == index)
                            {
                                TeamHome = row[0].ToString();
                            }
                            if (PilihanAway == index)
                            {
                                TeamAway = row[0].ToString();
                            }
                            index++;
                        }

                        foreach (DataRow row in dtMATCH.Rows)
                        {
                            if (row[2].ToString() == TeamHome)
                            {
                                if (row[3].ToString() == TeamAway)
                                {
                                    tb_matchID.Text = row[0].ToString();
                                    MatchID = row[0].ToString();
                                    //dtp_match.Value = row[1].ToString();
                                }
                            }
                        }

                        MunculDGV();
                        masukinCBTeam();

                    }
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void MunculDGV()
        {
            sql = $"select dmatch.minute as Minute, team.team_name as Team, player.player_name as Player, dmatch.type as Type from dmatch join team on team.team_id = dmatch.team_id join player on player.player_id = dmatch.player_id where dmatch.match_id = {MatchID}";
            cmd = new MySqlCommand(sql, conn);

            dtDMATCH = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtDMATCH);

            dgv_DMATCH.DataSource = dtDMATCH;
        }
        public void masukinCBTeam()
        {
            cb_teamINPUT.Items.Clear();
            cb_teamINPUT.Items.Add(TeamAway);
            cb_teamINPUT.Items.Add(TeamHome);
        }
        string TeamTerpilih;
        private void cb_teamINPUT_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_player.Items.Clear();
            TeamTerpilih = cb_teamINPUT.SelectedItem.ToString();
            sql = $"select player.player_name from player join team on team.team_id = player.team_id where team.team_name = '{TeamTerpilih}'";
            cmd = new MySqlCommand(sql, conn);

            dtPlayer = new DataTable();
            adapter = new MySqlDataAdapter(cmd);
            adapter.Fill(dtPlayer);

            foreach(DataRow row in dtPlayer.Rows)
            {
                cb_player.Items.Add(row[0]);
            }
        }

        private void dtp_match_ValueChanged(object sender, EventArgs e)
        {
            DateTime dt = new DateTime(2014,2,14);
            if (dtp_match.Value < dt)
            {
                MessageBox.Show("Error!");
            }
        }

        private void bt_ADD_Click(object sender, EventArgs e)
        {
            if (tb_MINUTE.Text == "" || cb_teamINPUT.SelectedIndex == -1 || cb_player.SelectedIndex == -1 || cb_TYPE.SelectedIndex == -1)
            {
                MessageBox.Show("ERROR!");
            }
            else
            {
                dtDMATCH.Rows.Add(tb_MINUTE.Text, TeamTerpilih, PlayerTerpilih, TypeTerpilih);
            }
        }

        string PlayerTerpilih;
        private void cb_player_SelectedIndexChanged(object sender, EventArgs e)
        {
            PlayerTerpilih = cb_player.SelectedItem.ToString();
        }
        string TypeTerpilih;
        private void cb_TYPE_SelectedIndexChanged(object sender, EventArgs e)
        {
            TypeTerpilih = cb_TYPE.SelectedItem.ToString();
        }

        private void bt_Delete_Click(object sender, EventArgs e)
        {
            dgv_DMATCH.Rows.RemoveAt(remove);
        }
        int remove;
        private void dgv_DMATCH_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            remove = e.RowIndex;
        }
    }
}

