﻿namespace TH05_Appdev
{
    partial class f_shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Product = new System.Windows.Forms.Label();
            this.lb_Nama = new System.Windows.Forms.Label();
            this.lb_Details = new System.Windows.Forms.Label();
            this.lb_Category = new System.Windows.Forms.Label();
            this.dgv_product = new System.Windows.Forms.DataGridView();
            this.dgv_category = new System.Windows.Forms.DataGridView();
            this.lb_category1 = new System.Windows.Forms.Label();
            this.lb_Harga = new System.Windows.Forms.Label();
            this.lb_stock = new System.Windows.Forms.Label();
            this.tb_NamaDetails = new System.Windows.Forms.TextBox();
            this.tb_harga = new System.Windows.Forms.TextBox();
            this.tb_stock = new System.Windows.Forms.TextBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.tb_namaCate = new System.Windows.Forms.TextBox();
            this.lb_nama1 = new System.Windows.Forms.Label();
            this.bt_all = new System.Windows.Forms.Button();
            this.bt_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.bt_addP = new System.Windows.Forms.Button();
            this.bt_editP = new System.Windows.Forms.Button();
            this.bt_removeP = new System.Windows.Forms.Button();
            this.bt_removeC = new System.Windows.Forms.Button();
            this.bt_addC = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(73, 63);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(125, 36);
            this.lb_Product.TabIndex = 0;
            this.lb_Product.Text = "Product";
            // 
            // lb_Nama
            // 
            this.lb_Nama.AutoSize = true;
            this.lb_Nama.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Nama.Location = new System.Drawing.Point(74, 523);
            this.lb_Nama.Name = "lb_Nama";
            this.lb_Nama.Size = new System.Drawing.Size(81, 27);
            this.lb_Nama.TabIndex = 1;
            this.lb_Nama.Text = "Nama :";
            // 
            // lb_Details
            // 
            this.lb_Details.AutoSize = true;
            this.lb_Details.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Details.Location = new System.Drawing.Point(73, 463);
            this.lb_Details.Name = "lb_Details";
            this.lb_Details.Size = new System.Drawing.Size(109, 36);
            this.lb_Details.TabIndex = 2;
            this.lb_Details.Text = "Details";
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(1001, 61);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(140, 36);
            this.lb_Category.TabIndex = 3;
            this.lb_Category.Text = "Category";
            // 
            // dgv_product
            // 
            this.dgv_product.AllowUserToAddRows = false;
            this.dgv_product.AllowUserToDeleteRows = false;
            this.dgv_product.AllowUserToResizeColumns = false;
            this.dgv_product.AllowUserToResizeRows = false;
            this.dgv_product.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_product.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_product.Location = new System.Drawing.Point(79, 126);
            this.dgv_product.Name = "dgv_product";
            this.dgv_product.ReadOnly = true;
            this.dgv_product.RowHeadersVisible = false;
            this.dgv_product.RowHeadersWidth = 82;
            this.dgv_product.RowTemplate.Height = 33;
            this.dgv_product.Size = new System.Drawing.Size(829, 301);
            this.dgv_product.TabIndex = 4;
            this.dgv_product.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgv_product_MouseClick);
            // 
            // dgv_category
            // 
            this.dgv_category.AllowUserToAddRows = false;
            this.dgv_category.AllowUserToDeleteRows = false;
            this.dgv_category.AllowUserToResizeColumns = false;
            this.dgv_category.AllowUserToResizeRows = false;
            this.dgv_category.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_category.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_category.Location = new System.Drawing.Point(1007, 126);
            this.dgv_category.Name = "dgv_category";
            this.dgv_category.ReadOnly = true;
            this.dgv_category.RowHeadersVisible = false;
            this.dgv_category.RowHeadersWidth = 82;
            this.dgv_category.RowTemplate.Height = 33;
            this.dgv_category.Size = new System.Drawing.Size(398, 301);
            this.dgv_category.TabIndex = 5;
            this.dgv_category.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dgv_category_MouseClick);
            // 
            // lb_category1
            // 
            this.lb_category1.AutoSize = true;
            this.lb_category1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_category1.Location = new System.Drawing.Point(44, 568);
            this.lb_category1.Name = "lb_category1";
            this.lb_category1.Size = new System.Drawing.Size(112, 27);
            this.lb_category1.TabIndex = 6;
            this.lb_category1.Text = "Category :";
            // 
            // lb_Harga
            // 
            this.lb_Harga.AutoSize = true;
            this.lb_Harga.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Harga.Location = new System.Drawing.Point(74, 613);
            this.lb_Harga.Name = "lb_Harga";
            this.lb_Harga.Size = new System.Drawing.Size(82, 27);
            this.lb_Harga.TabIndex = 7;
            this.lb_Harga.Text = "Harga :";
            // 
            // lb_stock
            // 
            this.lb_stock.AutoSize = true;
            this.lb_stock.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_stock.Location = new System.Drawing.Point(73, 655);
            this.lb_stock.Name = "lb_stock";
            this.lb_stock.Size = new System.Drawing.Size(78, 27);
            this.lb_stock.TabIndex = 8;
            this.lb_stock.Text = "Stock :";
            // 
            // tb_NamaDetails
            // 
            this.tb_NamaDetails.Location = new System.Drawing.Point(170, 523);
            this.tb_NamaDetails.Name = "tb_NamaDetails";
            this.tb_NamaDetails.Size = new System.Drawing.Size(362, 31);
            this.tb_NamaDetails.TabIndex = 9;
            // 
            // tb_harga
            // 
            this.tb_harga.Location = new System.Drawing.Point(170, 613);
            this.tb_harga.Name = "tb_harga";
            this.tb_harga.Size = new System.Drawing.Size(181, 31);
            this.tb_harga.TabIndex = 10;
            this.tb_harga.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_harga_KeyPress);
            // 
            // tb_stock
            // 
            this.tb_stock.Location = new System.Drawing.Point(170, 653);
            this.tb_stock.Name = "tb_stock";
            this.tb_stock.Size = new System.Drawing.Size(181, 31);
            this.tb_stock.TabIndex = 11;
            this.tb_stock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_stock_KeyPress);
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(170, 568);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(181, 33);
            this.cb_category.TabIndex = 12;
            // 
            // tb_namaCate
            // 
            this.tb_namaCate.Location = new System.Drawing.Point(1104, 469);
            this.tb_namaCate.Name = "tb_namaCate";
            this.tb_namaCate.Size = new System.Drawing.Size(301, 31);
            this.tb_namaCate.TabIndex = 14;
            // 
            // lb_nama1
            // 
            this.lb_nama1.AutoSize = true;
            this.lb_nama1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nama1.Location = new System.Drawing.Point(1008, 469);
            this.lb_nama1.Name = "lb_nama1";
            this.lb_nama1.Size = new System.Drawing.Size(81, 27);
            this.lb_nama1.TabIndex = 13;
            this.lb_nama1.Text = "Nama :";
            // 
            // bt_all
            // 
            this.bt_all.Location = new System.Drawing.Point(473, 65);
            this.bt_all.Name = "bt_all";
            this.bt_all.Size = new System.Drawing.Size(113, 39);
            this.bt_all.TabIndex = 15;
            this.bt_all.Text = "All";
            this.bt_all.UseVisualStyleBackColor = true;
            this.bt_all.Click += new System.EventHandler(this.bt_all_Click);
            // 
            // bt_filter
            // 
            this.bt_filter.Location = new System.Drawing.Point(592, 65);
            this.bt_filter.Name = "bt_filter";
            this.bt_filter.Size = new System.Drawing.Size(152, 39);
            this.bt_filter.TabIndex = 16;
            this.bt_filter.Text = "Filter :";
            this.bt_filter.UseVisualStyleBackColor = true;
            this.bt_filter.Click += new System.EventHandler(this.bt_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.Enabled = false;
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(757, 69);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(151, 33);
            this.cb_filter.TabIndex = 17;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // bt_addP
            // 
            this.bt_addP.BackColor = System.Drawing.Color.SandyBrown;
            this.bt_addP.Location = new System.Drawing.Point(569, 517);
            this.bt_addP.Name = "bt_addP";
            this.bt_addP.Size = new System.Drawing.Size(192, 45);
            this.bt_addP.TabIndex = 18;
            this.bt_addP.Text = "Add Product";
            this.bt_addP.UseVisualStyleBackColor = false;
            this.bt_addP.Click += new System.EventHandler(this.bt_addP_Click);
            // 
            // bt_editP
            // 
            this.bt_editP.BackColor = System.Drawing.Color.Peru;
            this.bt_editP.Location = new System.Drawing.Point(569, 568);
            this.bt_editP.Name = "bt_editP";
            this.bt_editP.Size = new System.Drawing.Size(192, 45);
            this.bt_editP.TabIndex = 19;
            this.bt_editP.Text = "Edit Product";
            this.bt_editP.UseVisualStyleBackColor = false;
            this.bt_editP.Click += new System.EventHandler(this.bt_editP_Click);
            // 
            // bt_removeP
            // 
            this.bt_removeP.BackColor = System.Drawing.Color.SaddleBrown;
            this.bt_removeP.Location = new System.Drawing.Point(569, 619);
            this.bt_removeP.Name = "bt_removeP";
            this.bt_removeP.Size = new System.Drawing.Size(192, 45);
            this.bt_removeP.TabIndex = 20;
            this.bt_removeP.Text = "Remove Product";
            this.bt_removeP.UseVisualStyleBackColor = false;
            this.bt_removeP.Click += new System.EventHandler(this.bt_removeP_Click);
            // 
            // bt_removeC
            // 
            this.bt_removeC.BackColor = System.Drawing.Color.Peru;
            this.bt_removeC.Location = new System.Drawing.Point(1227, 539);
            this.bt_removeC.Name = "bt_removeC";
            this.bt_removeC.Size = new System.Drawing.Size(192, 45);
            this.bt_removeC.TabIndex = 22;
            this.bt_removeC.Text = "Remove Category";
            this.bt_removeC.UseVisualStyleBackColor = false;
            this.bt_removeC.Click += new System.EventHandler(this.bt_removeC_Click);
            // 
            // bt_addC
            // 
            this.bt_addC.BackColor = System.Drawing.Color.SandyBrown;
            this.bt_addC.Location = new System.Drawing.Point(1014, 539);
            this.bt_addC.Name = "bt_addC";
            this.bt_addC.Size = new System.Drawing.Size(192, 45);
            this.bt_addC.TabIndex = 21;
            this.bt_addC.Text = "Add Category";
            this.bt_addC.UseVisualStyleBackColor = false;
            this.bt_addC.Click += new System.EventHandler(this.bt_addC_Click);
            // 
            // f_shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1567, 762);
            this.Controls.Add(this.bt_removeC);
            this.Controls.Add(this.bt_addC);
            this.Controls.Add(this.bt_removeP);
            this.Controls.Add(this.bt_editP);
            this.Controls.Add(this.bt_addP);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.bt_filter);
            this.Controls.Add(this.bt_all);
            this.Controls.Add(this.tb_namaCate);
            this.Controls.Add(this.lb_nama1);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.tb_stock);
            this.Controls.Add(this.tb_harga);
            this.Controls.Add(this.tb_NamaDetails);
            this.Controls.Add(this.lb_stock);
            this.Controls.Add(this.lb_Harga);
            this.Controls.Add(this.lb_category1);
            this.Controls.Add(this.dgv_category);
            this.Controls.Add(this.dgv_product);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.lb_Details);
            this.Controls.Add(this.lb_Nama);
            this.Controls.Add(this.lb_Product);
            this.Name = "f_shop";
            this.Text = "Shop";
            this.Load += new System.EventHandler(this.f_shop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_category)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Product;
        private System.Windows.Forms.Label lb_Nama;
        private System.Windows.Forms.Label lb_Details;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.DataGridView dgv_product;
        private System.Windows.Forms.DataGridView dgv_category;
        private System.Windows.Forms.Label lb_category1;
        private System.Windows.Forms.Label lb_Harga;
        private System.Windows.Forms.Label lb_stock;
        private System.Windows.Forms.TextBox tb_NamaDetails;
        private System.Windows.Forms.TextBox tb_harga;
        private System.Windows.Forms.TextBox tb_stock;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.TextBox tb_namaCate;
        private System.Windows.Forms.Label lb_nama1;
        private System.Windows.Forms.Button bt_all;
        private System.Windows.Forms.Button bt_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.Button bt_addP;
        private System.Windows.Forms.Button bt_editP;
        private System.Windows.Forms.Button bt_removeP;
        private System.Windows.Forms.Button bt_removeC;
        private System.Windows.Forms.Button bt_addC;
    }
}

