﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace TH05_Appdev
{
    public partial class f_shop : Form
    {
        DataTable Product;
        DataTable Category;
        DataTable ProductTampil;
        List<string> stringCategory = new List<string>();
        private bool filter;
        private int CategoryKe;
        public f_shop()
        {
            InitializeComponent();
            filter = false;
        }
        public void Isi_DGV ()
        {    
            Product = new DataTable();
            Product.Columns.Add("ID Product");
            Product.Columns.Add("Nama Product");
            Product.Columns.Add("Harga");
            Product.Columns.Add("Stock");
            Product.Columns.Add("ID Category");
            Product.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            Product.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            Product.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            Product.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            Product.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            Product.Rows.Add("C001", "Celana Pendek Cokelat", "60000", "11", "C4");
            Product.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            Product.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            dgv_product.DataSource = Product;

            ProductTampil = new DataTable();
            ProductTampil.Columns.Add("ID Product");
            ProductTampil.Columns.Add("Nama Product");
            ProductTampil.Columns.Add("Harga");
            ProductTampil.Columns.Add("Stock");
            ProductTampil.Columns.Add("ID Category");

            Category = new DataTable();
            Category.Columns.Add("ID Category");
            Category.Columns.Add("Nama Category");
            Category.Rows.Add("C1", "Jas");
            Category.Rows.Add("C2", "T-Shirt");
            Category.Rows.Add("C3", "Rok");
            Category.Rows.Add("C4", "Celana");
            Category.Rows.Add("C5", "Cawat");
            dgv_category.DataSource = Category;
        }

        private void f_shop_Load(object sender, EventArgs e)
        {
            Isi_DGV();
            dgv_category.ClearSelection();
            dgv_product.ClearSelection();
            foreach (DataRow row in Category.Rows)
            {
                cb_category.Items.Add(row["Nama Category"].ToString());
            }
        }

        private void bt_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Items.Clear();
            stringCategory.Clear();
            filter = true;
            cb_filter.Enabled = true;

            foreach (DataRow row in Category.Rows)
            {
                cb_filter.Items.Add(row["Nama Category"].ToString());
                stringCategory.Add(row["Nama Category"].ToString());
            }
            cb_filter.SelectedItem = null;
        }

        private void bt_all_Click(object sender, EventArgs e)
        {
            cb_filter.SelectedItem = null;
            filter = false;
            cb_filter.Enabled = false;
            dgv_product.DataSource = Product;
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_filter.SelectedItem == null)
            {

            }
            else
            {
                ProductTampil.Clear();
                int terpilih = cb_filter.SelectedIndex;
                string pilih = "";
                foreach (DataRow row in Category.Rows)
                {
                    if (stringCategory[terpilih].ToString() == row["Nama Category"].ToString())
                    {
                        pilih = row["ID Category"].ToString();
                    }
                }
                foreach (DataRow row in Product.Rows)
                {
                    if (pilih == row["ID Category"].ToString())
                    {
                        ProductTampil.Rows.Add(row[0], row[1], row[2], row[3], row[4]);
                    }
                }
                dgv_product.DataSource = ProductTampil;
            }
        }

        public DataGridViewRow daata;
        private string idProduct;
        private void dgv_product_MouseClick(object sender, MouseEventArgs e)
        {
            daata = dgv_product.CurrentRow;
            int ke = 0;
            int count = 0;
            foreach (DataRow row in Category.Rows)
            {
                if (daata.Cells[4].Value.ToString() == row["ID Category"].ToString())
                {
                    ke = count;
                }
                count++;
            }
            idProduct = daata.Cells[0].Value.ToString();
            tb_NamaDetails.Text = daata.Cells[1].Value.ToString();
            tb_harga.Text = daata.Cells[2].Value.ToString();
            tb_stock.Text = daata.Cells[3].Value.ToString();
            cb_category.SelectedIndex = ke;
        }

        private void bt_addP_Click(object sender, EventArgs e)
        {
            bool adaDouble = false;
            foreach (DataRow row in Product.Rows)
            {
                if (row["Nama product"].ToString() == tb_NamaDetails.Text)
                {
                    adaDouble = true;
                }
            }
            if (tb_NamaDetails.Text == "" || tb_harga.Text == "" || tb_stock.Text == "" || cb_category.SelectedItem == null)
            {
                MessageBox.Show("Tolong isi semua terlebih dahulu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (adaDouble == true)
            {
                MessageBox.Show("Sudah ada Product tersebut", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string nama = tb_NamaDetails.Text.Substring(0, 1).ToUpper();
                string idpro = "";
                int count = 0;
                foreach (DataRow row in Product.Rows)
                {
                    if (row["ID Product"].ToString().Contains(nama + "00"))
                    {
                        count = Convert.ToInt32(row["ID Product"].ToString().Substring(3, 1));
                    }
                    else if (row["ID Product"].ToString().Contains(nama + "0"))
                    {
                        count = Convert.ToInt32(row["ID Product"].ToString().Substring(2, 2));
                    }
                    else if (row["ID Product"].ToString().Contains(nama))
                    {
                        count = Convert.ToInt32(row["ID Product"].ToString().Substring(1, 3));
                    }
                }
                count = count + 1;
                if (count < 10)
                {
                    idpro = $"{nama[0]}00{count}";
                }
                else if (count < 100)
                {
                    idpro = $"{nama[0]}0{count}";
                }
                else
                {
                    idpro = $"{nama[0]}{count}";
                }

                string category1 = cb_category.SelectedItem.ToString();
                string idcat = "";
                foreach (DataRow row in Category.Rows)
                {
                    if (category1 == row["Nama Category"].ToString())
                    {
                        idcat = row["ID Category"].ToString();
                    }
                }
                Product.Rows.Add(idpro, tb_NamaDetails.Text, tb_harga.Text, tb_stock.Text, idcat);
                tb_NamaDetails.Clear();
                tb_harga.Clear();
                tb_stock.Clear();
                cb_category.SelectedItem = null;
            }
        }

        private void bt_editP_Click(object sender, EventArgs e)
        {
            if (dgv_product.SelectedCells.Count == 0)
            {
                MessageBox.Show("Pilih Dulu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (tb_stock.Text == "0")
                {
                    int ke = 0;
                    int count = 0;
                    foreach (DataRow row in Product.Rows)
                    {
                        if (row["ID Product"].ToString() == idProduct)
                        {
                            ke = count;
                        }
                        count++;
                    }
                    Product.Rows.RemoveAt(ke);
                }
                else
                {
                    string category1 = cb_category.SelectedItem.ToString();
                    string idcat = "";
                    foreach (DataRow row in Category.Rows)
                    {
                        if (category1 == row["Nama Category"].ToString())
                        {
                            idcat = row["ID Category"].ToString();
                        }
                    }
                    foreach (DataRow row in Product.Rows)
                    {
                        if (idProduct == row["ID Product"].ToString())
                        {
                            row["Nama Product"] = tb_NamaDetails.Text;
                            row["Harga"] = tb_harga.Text;
                            row["Stock"] = tb_stock.Text;
                            row["ID Category"] = idcat;
                        }
                    }
                }
                tb_NamaDetails.Clear();
                tb_harga.Clear();
                tb_stock.Clear();
                cb_category.SelectedItem = null;
                dgv_product.DataSource = Product;
                cb_filter.Enabled = false;
                cb_filter.SelectedItem = null;
            }
        }

        private void bt_removeP_Click(object sender, EventArgs e)
        {
            if (dgv_product.SelectedCells.Count == 0)
            {
                MessageBox.Show("Pilih Dulu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                int ke = 0;
                int count = 0;
                foreach (DataRow row in Product.Rows)
                {
                    if (row["ID Product"].ToString() == idProduct)
                    {
                        ke = count;
                    }
                    count++;
                }
                Product.Rows.RemoveAt(ke);
                tb_NamaDetails.Clear();
                tb_harga.Clear();
                tb_stock.Clear();
                cb_category.SelectedItem = null;
                dgv_product.DataSource = Product;
                cb_filter.Enabled = false;
                cb_filter.SelectedItem = null;
            }
        }

        private void bt_addC_Click(object sender, EventArgs e)
        {
            bool adaDouble = false;
            foreach (DataRow row in  Category.Rows)
            {
                if (row["Nama Category"].ToString() == tb_namaCate.Text)
                {
                    adaDouble = true;
                }
            }
            if (adaDouble == true)
            {
                MessageBox.Show("Sudah ada Category tersebut", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tb_namaCate.Clear();
            }
            else
            {
                daata = dgv_category.CurrentRow;
                CategoryKe = daata.Index;
                int ke = 0;
                int terakhir = 0;
                foreach (DataRow row in Category.Rows)
                {
                    if (ke == Category.Rows.Count - 1)
                    {
                        terakhir = Convert.ToInt32(row["ID Category"].ToString().Substring(1));
                    }
                    ke++;
                }
                string idCat = $"C{terakhir + 1}";
                Category.Rows.Add(idCat, tb_namaCate.Text);
                tb_namaCate.Clear();
                cb_category.Items.Clear();
                foreach (DataRow row in Category.Rows)
                {
                    cb_category.Items.Add(row["Nama Category"].ToString());
                }
            }
        }

        private void bt_removeC_Click(object sender, EventArgs e)
        {
            if (dgv_category.SelectedCells.Count == 0)
            {
                MessageBox.Show("Pilih Dulu", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {

                daata = dgv_category.CurrentRow;
                int id = daata.Index;
                for (int i = 0; i < Product.Rows.Count; i++)
                {
                    if (Product.Rows[i][4].ToString() == Category.Rows[id][0].ToString())
                    {
                        Product.Rows[i].Delete();
                        i = 0;
                    }
                }
                Category.Rows.RemoveAt(id);
            }
        }
        private void tb_harga_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
        }
        private void tb_stock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 46)
            {
                e.Handled = true;
            }
        }
        private void dgv_category_MouseClick(object sender, MouseEventArgs e)
        {
            daata = dgv_category.CurrentRow;
            tb_namaCate.Text = daata.Cells[1].Value.ToString();
        }
    }
}
