﻿namespace TakeHome_Appdev_Week_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_UCBank = new System.Windows.Forms.Label();
            this.lb_Username = new System.Windows.Forms.Label();
            this.lb_Password = new System.Windows.Forms.Label();
            this.tb_Username = new System.Windows.Forms.TextBox();
            this.tb_Password = new System.Windows.Forms.TextBox();
            this.bt_Login = new System.Windows.Forms.Button();
            this.bt_Register = new System.Windows.Forms.Button();
            this.p_LoginView = new System.Windows.Forms.Panel();
            this.lb_UCBank2 = new System.Windows.Forms.Label();
            this.p_Home = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.bt_Withdraw = new System.Windows.Forms.Button();
            this.bt_Deposit = new System.Windows.Forms.Button();
            this.lb_Uang = new System.Windows.Forms.Label();
            this.lb_Balance = new System.Windows.Forms.Label();
            this.bt_Logout = new System.Windows.Forms.Button();
            this.p_Deposit = new System.Windows.Forms.Panel();
            this.tx_InputD = new System.Windows.Forms.TextBox();
            this.lb_InputD = new System.Windows.Forms.Label();
            this.bt_DepositD = new System.Windows.Forms.Button();
            this.bt_LogOutD = new System.Windows.Forms.Button();
            this.lb_UCBank3 = new System.Windows.Forms.Label();
            this.p_Withdraw = new System.Windows.Forms.Panel();
            this.tx_InputW = new System.Windows.Forms.TextBox();
            this.lb_InputW = new System.Windows.Forms.Label();
            this.bt_WithdrawW = new System.Windows.Forms.Button();
            this.bt_LogoutW = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.p_Register = new System.Windows.Forms.Panel();
            this.bt_RegisterR = new System.Windows.Forms.Button();
            this.tb_PassR = new System.Windows.Forms.TextBox();
            this.tb_UserR = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_UCBank4 = new System.Windows.Forms.Label();
            this.p_LoginView.SuspendLayout();
            this.p_Home.SuspendLayout();
            this.p_Deposit.SuspendLayout();
            this.p_Withdraw.SuspendLayout();
            this.p_Register.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_UCBank
            // 
            this.lb_UCBank.AutoSize = true;
            this.lb_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank.Location = new System.Drawing.Point(70, 40);
            this.lb_UCBank.Name = "lb_UCBank";
            this.lb_UCBank.Size = new System.Drawing.Size(237, 61);
            this.lb_UCBank.TabIndex = 0;
            this.lb_UCBank.Text = "UC Bank";
            // 
            // lb_Username
            // 
            this.lb_Username.AutoSize = true;
            this.lb_Username.Location = new System.Drawing.Point(39, 145);
            this.lb_Username.Name = "lb_Username";
            this.lb_Username.Size = new System.Drawing.Size(116, 25);
            this.lb_Username.TabIndex = 1;
            this.lb_Username.Text = "Username:";
            // 
            // lb_Password
            // 
            this.lb_Password.AutoSize = true;
            this.lb_Password.Location = new System.Drawing.Point(43, 187);
            this.lb_Password.Name = "lb_Password";
            this.lb_Password.Size = new System.Drawing.Size(112, 25);
            this.lb_Password.TabIndex = 2;
            this.lb_Password.Text = "Password:";
            // 
            // tb_Username
            // 
            this.tb_Username.Location = new System.Drawing.Point(161, 145);
            this.tb_Username.Name = "tb_Username";
            this.tb_Username.Size = new System.Drawing.Size(139, 31);
            this.tb_Username.TabIndex = 3;
            // 
            // tb_Password
            // 
            this.tb_Password.Location = new System.Drawing.Point(161, 187);
            this.tb_Password.Name = "tb_Password";
            this.tb_Password.Size = new System.Drawing.Size(139, 31);
            this.tb_Password.TabIndex = 4;
            // 
            // bt_Login
            // 
            this.bt_Login.Location = new System.Drawing.Point(113, 244);
            this.bt_Login.Name = "bt_Login";
            this.bt_Login.Size = new System.Drawing.Size(125, 43);
            this.bt_Login.TabIndex = 5;
            this.bt_Login.Text = "Login";
            this.bt_Login.UseVisualStyleBackColor = true;
            this.bt_Login.Click += new System.EventHandler(this.bt_Login_Click);
            // 
            // bt_Register
            // 
            this.bt_Register.Location = new System.Drawing.Point(113, 304);
            this.bt_Register.Name = "bt_Register";
            this.bt_Register.Size = new System.Drawing.Size(125, 43);
            this.bt_Register.TabIndex = 6;
            this.bt_Register.Text = "Register";
            this.bt_Register.UseVisualStyleBackColor = true;
            this.bt_Register.Click += new System.EventHandler(this.bt_Register_Click);
            // 
            // p_LoginView
            // 
            this.p_LoginView.Controls.Add(this.bt_Register);
            this.p_LoginView.Controls.Add(this.bt_Login);
            this.p_LoginView.Controls.Add(this.tb_Password);
            this.p_LoginView.Controls.Add(this.tb_Username);
            this.p_LoginView.Controls.Add(this.lb_Password);
            this.p_LoginView.Controls.Add(this.lb_Username);
            this.p_LoginView.Controls.Add(this.lb_UCBank);
            this.p_LoginView.Location = new System.Drawing.Point(21, 27);
            this.p_LoginView.Name = "p_LoginView";
            this.p_LoginView.Size = new System.Drawing.Size(387, 394);
            this.p_LoginView.TabIndex = 7;
            // 
            // lb_UCBank2
            // 
            this.lb_UCBank2.AutoSize = true;
            this.lb_UCBank2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank2.Location = new System.Drawing.Point(70, 40);
            this.lb_UCBank2.Name = "lb_UCBank2";
            this.lb_UCBank2.Size = new System.Drawing.Size(237, 61);
            this.lb_UCBank2.TabIndex = 0;
            this.lb_UCBank2.Text = "UC Bank";
            // 
            // p_Home
            // 
            this.p_Home.Controls.Add(this.label5);
            this.p_Home.Controls.Add(this.bt_Withdraw);
            this.p_Home.Controls.Add(this.bt_Deposit);
            this.p_Home.Controls.Add(this.lb_Uang);
            this.p_Home.Controls.Add(this.lb_Balance);
            this.p_Home.Controls.Add(this.bt_Logout);
            this.p_Home.Controls.Add(this.lb_UCBank2);
            this.p_Home.Location = new System.Drawing.Point(475, 427);
            this.p_Home.Name = "p_Home";
            this.p_Home.Size = new System.Drawing.Size(387, 394);
            this.p_Home.TabIndex = 9;
            this.p_Home.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(135, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Rp.";
            // 
            // bt_Withdraw
            // 
            this.bt_Withdraw.Location = new System.Drawing.Point(140, 304);
            this.bt_Withdraw.Name = "bt_Withdraw";
            this.bt_Withdraw.Size = new System.Drawing.Size(125, 43);
            this.bt_Withdraw.TabIndex = 8;
            this.bt_Withdraw.Text = "Withdraw";
            this.bt_Withdraw.UseVisualStyleBackColor = true;
            this.bt_Withdraw.Click += new System.EventHandler(this.bt_Withdraw_Click);
            // 
            // bt_Deposit
            // 
            this.bt_Deposit.Location = new System.Drawing.Point(140, 244);
            this.bt_Deposit.Name = "bt_Deposit";
            this.bt_Deposit.Size = new System.Drawing.Size(125, 43);
            this.bt_Deposit.TabIndex = 7;
            this.bt_Deposit.Text = "Deposit";
            this.bt_Deposit.UseVisualStyleBackColor = true;
            this.bt_Deposit.Click += new System.EventHandler(this.bt_Deposit_Click);
            // 
            // lb_Uang
            // 
            this.lb_Uang.AutoSize = true;
            this.lb_Uang.Location = new System.Drawing.Point(186, 193);
            this.lb_Uang.Name = "lb_Uang";
            this.lb_Uang.Size = new System.Drawing.Size(24, 25);
            this.lb_Uang.TabIndex = 8;
            this.lb_Uang.Text = "0";
            // 
            // lb_Balance
            // 
            this.lb_Balance.AutoSize = true;
            this.lb_Balance.Location = new System.Drawing.Point(24, 193);
            this.lb_Balance.Name = "lb_Balance";
            this.lb_Balance.Size = new System.Drawing.Size(96, 25);
            this.lb_Balance.TabIndex = 7;
            this.lb_Balance.Text = "Balance:";
            // 
            // bt_Logout
            // 
            this.bt_Logout.Location = new System.Drawing.Point(232, 126);
            this.bt_Logout.Name = "bt_Logout";
            this.bt_Logout.Size = new System.Drawing.Size(125, 43);
            this.bt_Logout.TabIndex = 7;
            this.bt_Logout.Text = "Log Out";
            this.bt_Logout.UseVisualStyleBackColor = true;
            this.bt_Logout.Click += new System.EventHandler(this.bt_Logout_Click);
            // 
            // p_Deposit
            // 
            this.p_Deposit.Controls.Add(this.tx_InputD);
            this.p_Deposit.Controls.Add(this.lb_InputD);
            this.p_Deposit.Controls.Add(this.bt_DepositD);
            this.p_Deposit.Controls.Add(this.bt_LogOutD);
            this.p_Deposit.Controls.Add(this.lb_UCBank3);
            this.p_Deposit.Location = new System.Drawing.Point(21, 427);
            this.p_Deposit.Name = "p_Deposit";
            this.p_Deposit.Size = new System.Drawing.Size(387, 394);
            this.p_Deposit.TabIndex = 10;
            this.p_Deposit.Visible = false;
            // 
            // tx_InputD
            // 
            this.tx_InputD.Location = new System.Drawing.Point(113, 270);
            this.tx_InputD.Name = "tx_InputD";
            this.tx_InputD.Size = new System.Drawing.Size(174, 31);
            this.tx_InputD.TabIndex = 8;
            // 
            // lb_InputD
            // 
            this.lb_InputD.AutoSize = true;
            this.lb_InputD.Location = new System.Drawing.Point(84, 224);
            this.lb_InputD.Name = "lb_InputD";
            this.lb_InputD.Size = new System.Drawing.Size(223, 25);
            this.lb_InputD.TabIndex = 7;
            this.lb_InputD.Text = "Input Deposit Amount:";
            // 
            // bt_DepositD
            // 
            this.bt_DepositD.Location = new System.Drawing.Point(140, 319);
            this.bt_DepositD.Name = "bt_DepositD";
            this.bt_DepositD.Size = new System.Drawing.Size(125, 43);
            this.bt_DepositD.TabIndex = 7;
            this.bt_DepositD.Text = "Deposit";
            this.bt_DepositD.UseVisualStyleBackColor = true;
            this.bt_DepositD.Click += new System.EventHandler(this.bt_DepositD_Click);
            // 
            // bt_LogOutD
            // 
            this.bt_LogOutD.Location = new System.Drawing.Point(232, 104);
            this.bt_LogOutD.Name = "bt_LogOutD";
            this.bt_LogOutD.Size = new System.Drawing.Size(125, 43);
            this.bt_LogOutD.TabIndex = 7;
            this.bt_LogOutD.Text = "Log Out";
            this.bt_LogOutD.UseVisualStyleBackColor = true;
            this.bt_LogOutD.Click += new System.EventHandler(this.bt_LogOutD_Click);
            // 
            // lb_UCBank3
            // 
            this.lb_UCBank3.AutoSize = true;
            this.lb_UCBank3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank3.Location = new System.Drawing.Point(70, 40);
            this.lb_UCBank3.Name = "lb_UCBank3";
            this.lb_UCBank3.Size = new System.Drawing.Size(237, 61);
            this.lb_UCBank3.TabIndex = 0;
            this.lb_UCBank3.Text = "UC Bank";
            // 
            // p_Withdraw
            // 
            this.p_Withdraw.Controls.Add(this.tx_InputW);
            this.p_Withdraw.Controls.Add(this.lb_InputW);
            this.p_Withdraw.Controls.Add(this.bt_WithdrawW);
            this.p_Withdraw.Controls.Add(this.bt_LogoutW);
            this.p_Withdraw.Controls.Add(this.label4);
            this.p_Withdraw.Location = new System.Drawing.Point(931, 427);
            this.p_Withdraw.Name = "p_Withdraw";
            this.p_Withdraw.Size = new System.Drawing.Size(387, 394);
            this.p_Withdraw.TabIndex = 11;
            this.p_Withdraw.Visible = false;
            // 
            // tx_InputW
            // 
            this.tx_InputW.Location = new System.Drawing.Point(113, 270);
            this.tx_InputW.Name = "tx_InputW";
            this.tx_InputW.Size = new System.Drawing.Size(174, 31);
            this.tx_InputW.TabIndex = 8;
            // 
            // lb_InputW
            // 
            this.lb_InputW.AutoSize = true;
            this.lb_InputW.Location = new System.Drawing.Point(84, 224);
            this.lb_InputW.Name = "lb_InputW";
            this.lb_InputW.Size = new System.Drawing.Size(239, 25);
            this.lb_InputW.TabIndex = 7;
            this.lb_InputW.Text = "Input Withdraw Amount:";
            // 
            // bt_WithdrawW
            // 
            this.bt_WithdrawW.Location = new System.Drawing.Point(140, 319);
            this.bt_WithdrawW.Name = "bt_WithdrawW";
            this.bt_WithdrawW.Size = new System.Drawing.Size(125, 43);
            this.bt_WithdrawW.TabIndex = 7;
            this.bt_WithdrawW.Text = "Withdraw";
            this.bt_WithdrawW.UseVisualStyleBackColor = true;
            this.bt_WithdrawW.Click += new System.EventHandler(this.bt_WithdrawW_Click);
            // 
            // bt_LogoutW
            // 
            this.bt_LogoutW.Location = new System.Drawing.Point(232, 104);
            this.bt_LogoutW.Name = "bt_LogoutW";
            this.bt_LogoutW.Size = new System.Drawing.Size(125, 43);
            this.bt_LogoutW.TabIndex = 7;
            this.bt_LogoutW.Text = "Log Out";
            this.bt_LogoutW.UseVisualStyleBackColor = true;
            this.bt_LogoutW.Click += new System.EventHandler(this.bt_LogoutW_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(70, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(237, 61);
            this.label4.TabIndex = 0;
            this.label4.Text = "UC Bank";
            // 
            // p_Register
            // 
            this.p_Register.Controls.Add(this.bt_RegisterR);
            this.p_Register.Controls.Add(this.tb_PassR);
            this.p_Register.Controls.Add(this.tb_UserR);
            this.p_Register.Controls.Add(this.label1);
            this.p_Register.Controls.Add(this.label2);
            this.p_Register.Controls.Add(this.lb_UCBank4);
            this.p_Register.Location = new System.Drawing.Point(475, 27);
            this.p_Register.Name = "p_Register";
            this.p_Register.Size = new System.Drawing.Size(387, 394);
            this.p_Register.TabIndex = 8;
            this.p_Register.Visible = false;
            // 
            // bt_RegisterR
            // 
            this.bt_RegisterR.Location = new System.Drawing.Point(123, 244);
            this.bt_RegisterR.Name = "bt_RegisterR";
            this.bt_RegisterR.Size = new System.Drawing.Size(125, 43);
            this.bt_RegisterR.TabIndex = 6;
            this.bt_RegisterR.Text = "Register";
            this.bt_RegisterR.UseVisualStyleBackColor = true;
            this.bt_RegisterR.Click += new System.EventHandler(this.bt_RegisterR_Click);
            // 
            // tb_PassR
            // 
            this.tb_PassR.Location = new System.Drawing.Point(161, 187);
            this.tb_PassR.Name = "tb_PassR";
            this.tb_PassR.Size = new System.Drawing.Size(139, 31);
            this.tb_PassR.TabIndex = 4;
            // 
            // tb_UserR
            // 
            this.tb_UserR.Location = new System.Drawing.Point(161, 145);
            this.tb_UserR.Name = "tb_UserR";
            this.tb_UserR.Size = new System.Drawing.Size(139, 31);
            this.tb_UserR.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 187);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username:";
            // 
            // lb_UCBank4
            // 
            this.lb_UCBank4.AutoSize = true;
            this.lb_UCBank4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank4.Location = new System.Drawing.Point(70, 40);
            this.lb_UCBank4.Name = "lb_UCBank4";
            this.lb_UCBank4.Size = new System.Drawing.Size(237, 61);
            this.lb_UCBank4.TabIndex = 0;
            this.lb_UCBank4.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1513, 861);
            this.Controls.Add(this.p_Register);
            this.Controls.Add(this.p_Withdraw);
            this.Controls.Add(this.p_Deposit);
            this.Controls.Add(this.p_Home);
            this.Controls.Add(this.p_LoginView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.p_LoginView.ResumeLayout(false);
            this.p_LoginView.PerformLayout();
            this.p_Home.ResumeLayout(false);
            this.p_Home.PerformLayout();
            this.p_Deposit.ResumeLayout(false);
            this.p_Deposit.PerformLayout();
            this.p_Withdraw.ResumeLayout(false);
            this.p_Withdraw.PerformLayout();
            this.p_Register.ResumeLayout(false);
            this.p_Register.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_UCBank;
        private System.Windows.Forms.Label lb_Username;
        private System.Windows.Forms.Label lb_Password;
        private System.Windows.Forms.TextBox tb_Username;
        private System.Windows.Forms.TextBox tb_Password;
        private System.Windows.Forms.Button bt_Login;
        private System.Windows.Forms.Button bt_Register;
        private System.Windows.Forms.Panel p_LoginView;
        private System.Windows.Forms.Label lb_UCBank2;
        private System.Windows.Forms.Panel p_Home;
        private System.Windows.Forms.Button bt_Withdraw;
        private System.Windows.Forms.Button bt_Deposit;
        private System.Windows.Forms.Label lb_Uang;
        private System.Windows.Forms.Label lb_Balance;
        private System.Windows.Forms.Button bt_Logout;
        private System.Windows.Forms.Panel p_Deposit;
        private System.Windows.Forms.TextBox tx_InputD;
        private System.Windows.Forms.Label lb_InputD;
        private System.Windows.Forms.Button bt_DepositD;
        private System.Windows.Forms.Button bt_LogOutD;
        private System.Windows.Forms.Label lb_UCBank3;
        private System.Windows.Forms.Panel p_Withdraw;
        private System.Windows.Forms.TextBox tx_InputW;
        private System.Windows.Forms.Label lb_InputW;
        private System.Windows.Forms.Button bt_WithdrawW;
        private System.Windows.Forms.Button bt_LogoutW;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel p_Register;
        private System.Windows.Forms.Button bt_RegisterR;
        private System.Windows.Forms.TextBox tb_PassR;
        private System.Windows.Forms.TextBox tb_UserR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_UCBank4;
        private System.Windows.Forms.Label label5;
    }
}

