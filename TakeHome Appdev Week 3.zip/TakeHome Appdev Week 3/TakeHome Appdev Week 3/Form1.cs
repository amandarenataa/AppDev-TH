﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome_Appdev_Week_3
{
    public partial class Form1 : Form
    {
        public List<string> NamaRekening = new List<string>();
        public List<string> PassRekening = new List<string> ();
        public List<int> BalanceRek = new List<int>();
        public int count;
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_Login_Click(object sender, EventArgs e)
        {
            if (NamaRekening == null)
            {
                MessageBox.Show("Belum ada Rekening yang terdaftar");
            }
            else
            {
                bool nemu = false;
                for (int i = 0; i < NamaRekening.Count; i++)
                {
                    if (NamaRekening[i] == tb_Username.Text)
                    {
                        nemu = true;
                        count = i;
                    }
                }
                if (nemu == false)
                {
                    MessageBox.Show("Tidak ditemukan Nama Rekening");
                    tb_Username.Clear();
                    tb_Password.Clear();
                }
                else
                {
                    if (PassRekening[count] == tb_Password.Text)
                    {
                        MessageBox.Show("Login Successful");
                        p_LoginView.Visible = false;
                        p_Home.Visible = true;
                        lb_Uang.Text = Convert.ToString(BalanceRek[count].ToString("N2", CultureInfo.InvariantCulture));
                    }
                    else
                    {
                        MessageBox.Show("Password Salah");
                        tb_Password.Clear();
                    }
                }
            }
        }

        private void bt_Register_Click(object sender, EventArgs e)
        {
            p_LoginView.Visible = false;
            p_Register.Visible = true;
        }

        private void bt_RegisterR_Click(object sender, EventArgs e)
        {
            if (NamaRekening == null)
            {
                NamaRekening.Add(tb_UserR.Text);
                PassRekening.Add(tb_PassR.Text);
                BalanceRek.Add(0);
                MessageBox.Show("Register Successful");
                tb_UserR.Clear();
                tb_PassR.Clear();
                p_LoginView.Visible = true;
                p_Register.Visible = false;
            }
            else
            {
                if (NamaRekening.Contains(tb_UserR.Text))
                {
                    MessageBox.Show("Username has been used, try again");
                }
                else
                {
                    NamaRekening.Add(tb_UserR.Text);
                    PassRekening.Add(tb_PassR.Text);
                    BalanceRek.Add(0);
                    MessageBox.Show("Register Successful");
                    tb_UserR.Clear();
                    tb_PassR.Clear();
                    p_LoginView.Visible = true;
                    p_Register.Visible = false;
                }
            }
        }

        private void bt_Logout_Click(object sender, EventArgs e)
        {
            p_Home.Visible = false;
            p_LoginView.Visible = true;
            tb_Username.Clear();
            tb_Password.Clear();
        }

        private void bt_Deposit_Click(object sender, EventArgs e)
        {
            p_Home.Visible = false;
            p_Deposit.Visible = true;
            tb_Username.Clear();
            tb_Password.Clear();
        }

        private void bt_LogOutD_Click(object sender, EventArgs e)
        {
            p_Deposit.Visible = false;
            p_LoginView.Visible = true;
            tb_Username.Clear();
            tb_Password.Clear();
        }

        private void bt_DepositD_Click(object sender, EventArgs e)
        {
            int deposit = Convert.ToInt32(tx_InputD.Text);
            if (deposit <= 0)
            {
                MessageBox.Show("Deposit can't be 0");
            }
            else
            {
                BalanceRek[count] += deposit;
                lb_Uang.Text = Convert.ToString(BalanceRek[count].ToString("N2", CultureInfo.InvariantCulture));
                MessageBox.Show("Deposit Successful");
                tx_InputD.Clear();
                p_Deposit.Visible = false;
                p_Home.Visible = true;
            }
        }

        private void bt_Withdraw_Click(object sender, EventArgs e)
        {
            p_Withdraw.Visible = true;
            p_Home.Visible = false;
        }

        private void bt_LogoutW_Click(object sender, EventArgs e)
        {
            p_Withdraw.Visible = false;
            p_LoginView.Visible = true;
        }

        private void bt_WithdrawW_Click(object sender, EventArgs e)
        {
            int withdraw = Convert.ToInt32(tx_InputW.Text);
            if (withdraw <= 0)
            {
                MessageBox.Show("Withdraw tidak bisa 0");
            }
            else
            {
                if (BalanceRek[count] >= withdraw)
                {
                    BalanceRek[count] -= withdraw;
                    lb_Uang.Text = Convert.ToString(BalanceRek[count].ToString("N2", CultureInfo.InvariantCulture));
                    MessageBox.Show("Withdraw Successful");
                    tx_InputW.Clear();
                    p_Withdraw.Visible = false;
                    p_Home.Visible = true;
                }
                else
                {
                    MessageBox.Show("not enough balance to withdraw");
                }
            }
        }
    }
}
