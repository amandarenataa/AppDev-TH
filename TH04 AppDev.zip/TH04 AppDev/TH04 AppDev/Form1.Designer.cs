﻿namespace TH04_AppDev
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_teamlist = new System.Windows.Forms.Label();
            this.lb_choosecountry = new System.Windows.Forms.Label();
            this.lb_chooseteam = new System.Windows.Forms.Label();
            this.listB_soccerteam = new System.Windows.Forms.ListBox();
            this.bt_removelist = new System.Windows.Forms.Button();
            this.tb_teamcountry = new System.Windows.Forms.TextBox();
            this.lb_teamcountry = new System.Windows.Forms.Label();
            this.tb_teamname = new System.Windows.Forms.TextBox();
            this.lb_teamname = new System.Windows.Forms.Label();
            this.lb_addingteam = new System.Windows.Forms.Label();
            this.tb_teamcity = new System.Windows.Forms.TextBox();
            this.lb_teamcity = new System.Windows.Forms.Label();
            this.bt_addteam = new System.Windows.Forms.Button();
            this.bt_addplayer = new System.Windows.Forms.Button();
            this.lb_playerposition = new System.Windows.Forms.Label();
            this.tb_playernumber = new System.Windows.Forms.TextBox();
            this.lb_playernumber = new System.Windows.Forms.Label();
            this.tb_playername = new System.Windows.Forms.TextBox();
            this.lb_playername = new System.Windows.Forms.Label();
            this.lb_addingplayers = new System.Windows.Forms.Label();
            this.cb_playerposition = new System.Windows.Forms.ComboBox();
            this.cb_country = new System.Windows.Forms.ComboBox();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lb_teamlist
            // 
            this.lb_teamlist.AutoSize = true;
            this.lb_teamlist.Location = new System.Drawing.Point(125, 76);
            this.lb_teamlist.Name = "lb_teamlist";
            this.lb_teamlist.Size = new System.Drawing.Size(179, 25);
            this.lb_teamlist.TabIndex = 0;
            this.lb_teamlist.Text = "Soccer Team List";
            // 
            // lb_choosecountry
            // 
            this.lb_choosecountry.AutoSize = true;
            this.lb_choosecountry.Location = new System.Drawing.Point(32, 162);
            this.lb_choosecountry.Name = "lb_choosecountry";
            this.lb_choosecountry.Size = new System.Drawing.Size(173, 25);
            this.lb_choosecountry.TabIndex = 1;
            this.lb_choosecountry.Text = "Choose Country:";
            // 
            // lb_chooseteam
            // 
            this.lb_chooseteam.AutoSize = true;
            this.lb_chooseteam.Location = new System.Drawing.Point(32, 215);
            this.lb_chooseteam.Name = "lb_chooseteam";
            this.lb_chooseteam.Size = new System.Drawing.Size(152, 25);
            this.lb_chooseteam.TabIndex = 3;
            this.lb_chooseteam.Text = "Choose Team:";
            // 
            // listB_soccerteam
            // 
            this.listB_soccerteam.FormattingEnabled = true;
            this.listB_soccerteam.ItemHeight = 25;
            this.listB_soccerteam.Location = new System.Drawing.Point(37, 276);
            this.listB_soccerteam.Name = "listB_soccerteam";
            this.listB_soccerteam.Size = new System.Drawing.Size(348, 229);
            this.listB_soccerteam.TabIndex = 5;
            // 
            // bt_removelist
            // 
            this.bt_removelist.Location = new System.Drawing.Point(37, 536);
            this.bt_removelist.Name = "bt_removelist";
            this.bt_removelist.Size = new System.Drawing.Size(155, 40);
            this.bt_removelist.TabIndex = 6;
            this.bt_removelist.Text = "Remove";
            this.bt_removelist.UseVisualStyleBackColor = true;
            this.bt_removelist.Click += new System.EventHandler(this.bt_removelist_Click);
            // 
            // tb_teamcountry
            // 
            this.tb_teamcountry.Location = new System.Drawing.Point(700, 215);
            this.tb_teamcountry.Name = "tb_teamcountry";
            this.tb_teamcountry.Size = new System.Drawing.Size(174, 31);
            this.tb_teamcountry.TabIndex = 11;
            // 
            // lb_teamcountry
            // 
            this.lb_teamcountry.AutoSize = true;
            this.lb_teamcountry.Location = new System.Drawing.Point(521, 215);
            this.lb_teamcountry.Name = "lb_teamcountry";
            this.lb_teamcountry.Size = new System.Drawing.Size(153, 25);
            this.lb_teamcountry.TabIndex = 10;
            this.lb_teamcountry.Text = "Team Country:";
            // 
            // tb_teamname
            // 
            this.tb_teamname.Location = new System.Drawing.Point(700, 159);
            this.tb_teamname.Name = "tb_teamname";
            this.tb_teamname.Size = new System.Drawing.Size(174, 31);
            this.tb_teamname.TabIndex = 9;
            // 
            // lb_teamname
            // 
            this.lb_teamname.AutoSize = true;
            this.lb_teamname.Location = new System.Drawing.Point(521, 162);
            this.lb_teamname.Name = "lb_teamname";
            this.lb_teamname.Size = new System.Drawing.Size(134, 25);
            this.lb_teamname.TabIndex = 8;
            this.lb_teamname.Text = "Team Name:";
            // 
            // lb_addingteam
            // 
            this.lb_addingteam.AutoSize = true;
            this.lb_addingteam.Location = new System.Drawing.Point(614, 76);
            this.lb_addingteam.Name = "lb_addingteam";
            this.lb_addingteam.Size = new System.Drawing.Size(139, 25);
            this.lb_addingteam.TabIndex = 7;
            this.lb_addingteam.Text = "Adding Team";
            // 
            // tb_teamcity
            // 
            this.tb_teamcity.Location = new System.Drawing.Point(700, 265);
            this.tb_teamcity.Name = "tb_teamcity";
            this.tb_teamcity.Size = new System.Drawing.Size(174, 31);
            this.tb_teamcity.TabIndex = 13;
            // 
            // lb_teamcity
            // 
            this.lb_teamcity.AutoSize = true;
            this.lb_teamcity.Location = new System.Drawing.Point(521, 268);
            this.lb_teamcity.Name = "lb_teamcity";
            this.lb_teamcity.Size = new System.Drawing.Size(115, 25);
            this.lb_teamcity.TabIndex = 12;
            this.lb_teamcity.Text = "Team City:";
            // 
            // bt_addteam
            // 
            this.bt_addteam.Location = new System.Drawing.Point(626, 351);
            this.bt_addteam.Name = "bt_addteam";
            this.bt_addteam.Size = new System.Drawing.Size(155, 40);
            this.bt_addteam.TabIndex = 14;
            this.bt_addteam.Text = "Add";
            this.bt_addteam.UseVisualStyleBackColor = true;
            this.bt_addteam.Click += new System.EventHandler(this.bt_addteam_Click);
            // 
            // bt_addplayer
            // 
            this.bt_addplayer.Location = new System.Drawing.Point(1042, 348);
            this.bt_addplayer.Name = "bt_addplayer";
            this.bt_addplayer.Size = new System.Drawing.Size(155, 40);
            this.bt_addplayer.TabIndex = 22;
            this.bt_addplayer.Text = "Add";
            this.bt_addplayer.UseVisualStyleBackColor = true;
            this.bt_addplayer.Click += new System.EventHandler(this.bt_addplayer_Click);
            // 
            // lb_playerposition
            // 
            this.lb_playerposition.AutoSize = true;
            this.lb_playerposition.Location = new System.Drawing.Point(937, 265);
            this.lb_playerposition.Name = "lb_playerposition";
            this.lb_playerposition.Size = new System.Drawing.Size(162, 25);
            this.lb_playerposition.TabIndex = 20;
            this.lb_playerposition.Text = "Player Position:";
            // 
            // tb_playernumber
            // 
            this.tb_playernumber.Location = new System.Drawing.Point(1116, 212);
            this.tb_playernumber.Name = "tb_playernumber";
            this.tb_playernumber.Size = new System.Drawing.Size(174, 31);
            this.tb_playernumber.TabIndex = 19;
            // 
            // lb_playernumber
            // 
            this.lb_playernumber.AutoSize = true;
            this.lb_playernumber.Location = new System.Drawing.Point(937, 212);
            this.lb_playernumber.Name = "lb_playernumber";
            this.lb_playernumber.Size = new System.Drawing.Size(160, 25);
            this.lb_playernumber.TabIndex = 18;
            this.lb_playernumber.Text = "Player Number:";
            // 
            // tb_playername
            // 
            this.tb_playername.Location = new System.Drawing.Point(1116, 156);
            this.tb_playername.Name = "tb_playername";
            this.tb_playername.Size = new System.Drawing.Size(174, 31);
            this.tb_playername.TabIndex = 17;
            // 
            // lb_playername
            // 
            this.lb_playername.AutoSize = true;
            this.lb_playername.Location = new System.Drawing.Point(937, 159);
            this.lb_playername.Name = "lb_playername";
            this.lb_playername.Size = new System.Drawing.Size(141, 25);
            this.lb_playername.TabIndex = 16;
            this.lb_playername.Text = "Player Name:";
            // 
            // lb_addingplayers
            // 
            this.lb_addingplayers.AutoSize = true;
            this.lb_addingplayers.Location = new System.Drawing.Point(1030, 73);
            this.lb_addingplayers.Name = "lb_addingplayers";
            this.lb_addingplayers.Size = new System.Drawing.Size(157, 25);
            this.lb_addingplayers.TabIndex = 15;
            this.lb_addingplayers.Text = "Adding Players";
            // 
            // cb_playerposition
            // 
            this.cb_playerposition.FormattingEnabled = true;
            this.cb_playerposition.Items.AddRange(new object[] {
            "GK",
            "DF",
            "MF",
            "FW"});
            this.cb_playerposition.Location = new System.Drawing.Point(1116, 265);
            this.cb_playerposition.Name = "cb_playerposition";
            this.cb_playerposition.Size = new System.Drawing.Size(174, 33);
            this.cb_playerposition.TabIndex = 23;
            // 
            // cb_country
            // 
            this.cb_country.FormattingEnabled = true;
            this.cb_country.Location = new System.Drawing.Point(211, 162);
            this.cb_country.Name = "cb_country";
            this.cb_country.Size = new System.Drawing.Size(174, 33);
            this.cb_country.TabIndex = 24;
            this.cb_country.SelectedIndexChanged += new System.EventHandler(this.cb_country_SelectedIndexChanged);
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(211, 210);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(174, 33);
            this.cb_team.TabIndex = 25;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1406, 742);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.cb_country);
            this.Controls.Add(this.cb_playerposition);
            this.Controls.Add(this.bt_addplayer);
            this.Controls.Add(this.lb_playerposition);
            this.Controls.Add(this.tb_playernumber);
            this.Controls.Add(this.lb_playernumber);
            this.Controls.Add(this.tb_playername);
            this.Controls.Add(this.lb_playername);
            this.Controls.Add(this.lb_addingplayers);
            this.Controls.Add(this.bt_addteam);
            this.Controls.Add(this.tb_teamcity);
            this.Controls.Add(this.lb_teamcity);
            this.Controls.Add(this.tb_teamcountry);
            this.Controls.Add(this.lb_teamcountry);
            this.Controls.Add(this.tb_teamname);
            this.Controls.Add(this.lb_teamname);
            this.Controls.Add(this.lb_addingteam);
            this.Controls.Add(this.bt_removelist);
            this.Controls.Add(this.listB_soccerteam);
            this.Controls.Add(this.lb_chooseteam);
            this.Controls.Add(this.lb_choosecountry);
            this.Controls.Add(this.lb_teamlist);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_teamlist;
        private System.Windows.Forms.Label lb_choosecountry;
        private System.Windows.Forms.Label lb_chooseteam;
        private System.Windows.Forms.ListBox listB_soccerteam;
        private System.Windows.Forms.Button bt_removelist;
        private System.Windows.Forms.TextBox tb_teamcountry;
        private System.Windows.Forms.Label lb_teamcountry;
        private System.Windows.Forms.TextBox tb_teamname;
        private System.Windows.Forms.Label lb_teamname;
        private System.Windows.Forms.Label lb_addingteam;
        private System.Windows.Forms.TextBox tb_teamcity;
        private System.Windows.Forms.Label lb_teamcity;
        private System.Windows.Forms.Button bt_addteam;
        private System.Windows.Forms.Button bt_addplayer;
        private System.Windows.Forms.Label lb_playerposition;
        private System.Windows.Forms.TextBox tb_playernumber;
        private System.Windows.Forms.Label lb_playernumber;
        private System.Windows.Forms.TextBox tb_playername;
        private System.Windows.Forms.Label lb_playername;
        private System.Windows.Forms.Label lb_addingplayers;
        private System.Windows.Forms.ComboBox cb_playerposition;
        private System.Windows.Forms.ComboBox cb_country;
        private System.Windows.Forms.ComboBox cb_team;
    }
}

