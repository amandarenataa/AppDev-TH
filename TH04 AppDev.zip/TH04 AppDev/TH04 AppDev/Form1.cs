﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_AppDev
{
    public partial class Form1 : Form
    {
        List<string> Country = new List<string>();
        List<string> Teams = new List<string>();
        DataTable Team = new DataTable();
        string CountryYgDipilih;
        string TeamYgDipilih;
        public Form1()
        {
            InitializeComponent();
        }
        public void DataAwal()
        {
            Team.Columns.Add("Country");
            Team.Columns.Add("Team");
            Team.Columns.Add("Nomor");
            Team.Columns.Add("Nama");
            Team.Columns.Add("Posisi");

            Team.Rows.Add("England", "Manchester","01", "Jennie", "GK");
            Team.Rows.Add("England", "Manchester", "02", "Jisoo", "DF");
            Team.Rows.Add("England", "Manchester", "03", "Rose", "DF");
            Team.Rows.Add("England", "Manchester", "04", "Lisa", "DF");
            Team.Rows.Add("England", "Manchester", "05", "Irene", "DF");
            Team.Rows.Add("England", "Manchester", "06", "Seulgi", "MF");
            Team.Rows.Add("England", "Manchester", "07", "Wendy", "FW");
            Team.Rows.Add("England", "Manchester", "08", "Joy", "FW");
            Team.Rows.Add("England", "Manchester", "09", "Yeri", "DF");
            Team.Rows.Add("England", "Manchester", "10", "Hyeju", "MF");
            Team.Rows.Add("England", "Manchester", "11", "Gowon", "MF");

            Team.Rows.Add("England", "Chelsea", "01", "Nayeon", "GK");
            Team.Rows.Add("England", "Chelsea", "02", "Jeongyeon", "DF");
            Team.Rows.Add("England", "Chelsea", "03", "Momo", "DF");
            Team.Rows.Add("England", "Chelsea", "04", "Sana", "DF");
            Team.Rows.Add("England", "Chelsea", "05", "Jihyo", "DF");
            Team.Rows.Add("England", "Chelsea", "06", "Mina", "MF");
            Team.Rows.Add("England", "Chelsea", "07", "Dahyun", "FW");
            Team.Rows.Add("England", "Chelsea", "08", "Chaeyeong", "FW");
            Team.Rows.Add("England", "Chelsea", "09", "Tzuyu", "DF");
            Team.Rows.Add("England", "Chelsea", "10", "Shuhua", "MF");
            Team.Rows.Add("England", "Chelsea", "11", "Soojin", "MF");

            Team.Rows.Add("Germany", "Bayern", "01", "Eunbi", "GK");
            Team.Rows.Add("Germany", "Bayern", "02", "Sakura", "DF");
            Team.Rows.Add("Germany", "Bayern", "03", "Hyewon", "DF");
            Team.Rows.Add("Germany", "Bayern", "04", "Yena", "DF");
            Team.Rows.Add("Germany", "Bayern", "05", "Chaeyeon", "DF");
            Team.Rows.Add("Germany", "Bayern", "06", "Chaewon", "MF");
            Team.Rows.Add("Germany", "Bayern", "07", "Minju", "FW");
            Team.Rows.Add("Germany", "Bayern", "08", "Nako", "FW");
            Team.Rows.Add("Germany", "Bayern", "09", "Hitomi", "DF");
            Team.Rows.Add("Germany", "Bayern", "10", "Yuri", "MF");
            Team.Rows.Add("Germany", "Bayern", "11", "Yujin", "MF");
            Team.Rows.Add("Germany", "Bayern", "12", "Wonyoung", "MF");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            DataAwal();
            foreach (DataRow row in Team.Rows)
            {
                if (!Country.Contains(row["Country"].ToString()))
                {
                    Country.Add(row["Country"].ToString());
                    cb_country.Items.Add(row["Country"].ToString());
                }
            }
        }
        private void bt_removelist_Click(object sender, EventArgs e)
        {
            if (listB_soccerteam.Items.Count <= 11)
            {
                MessageBox.Show("Players needs to be 11 minimal");
            }
            else
            {
                string remove = listB_soccerteam.SelectedItem.ToString();
                int index = -1;
                int rowKe = 0;
                listB_soccerteam.Items.Remove(listB_soccerteam.SelectedItem);
                foreach (DataRow row in Team.Rows)
                {
                    index++;
                    string playerInfo = "(" + row["Nomor"].ToString() + ")  "+ row["Nama"].ToString() + " - " + row["Posisi"].ToString();
                    if (playerInfo == remove)
                    {
                        rowKe = index;
                    }
                }
                Team.Rows.RemoveAt(rowKe);
            }
        }
        private void cb_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            CountryYgDipilih = cb_country.Text;
            cb_team.SelectedItem = null;
            listB_soccerteam.Items.Clear();
            cb_team.Items.Clear();
            Teams.Clear();
            foreach (DataRow row in Team.Rows)
            {
                if (CountryYgDipilih == row["Country"].ToString())
                {
                    if (!Teams.Contains(row["Team"].ToString()))
                    {
                        Teams.Add(row["Team"].ToString());
                        cb_team.Items.Add(row["Team"].ToString());
                    }
                }
            }
        }
        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            TeamYgDipilih = cb_team.Text;
            listB_soccerteam.Items.Clear();

            foreach (DataRow row in Team.Rows)
            {
                if (TeamYgDipilih == row["Team"].ToString() && row["Nomor"].ToString() != "00")
                {
                    string playerInfo = "(" + row["Nomor"].ToString() + ")  " + row["Nama"].ToString() + " - " + row["Posisi"].ToString();
                    listB_soccerteam.Items.Add(playerInfo);
                }
            }
        }
        private void bt_addteam_Click(object sender, EventArgs e)
        {
            if (tb_teamcity.Text == "" || tb_teamcountry.Text == "" || tb_teamcity.Text == "")
            {
                MessageBox.Show("Tolong isi semua sebelum di add team");
            }
            else
            {
                foreach (DataRow row in Team.Rows)
                {
                    if (!Teams.Contains(row["Team"].ToString()))
                    {
                        Teams.Add(row["Team"].ToString());
                    }
                }
                if (Teams.Contains(tb_teamname.Text))
                {
                    MessageBox.Show("Nama Team Sudah Terdaftar");
                    tb_teamname.Clear();
                }
                else
                {
                    Team.Rows.Add(tb_teamcountry.Text, tb_teamname.Text, "00", "...", "...");
                    foreach (DataRow row in Team.Rows)
                    {
                        if (!Country.Contains(row["Country"].ToString()))
                        {
                            Country.Add(row["Country"].ToString());
                            cb_country.Items.Add(row["Country"].ToString());
                        }
                    }
                    tb_teamname.Clear();
                    tb_teamcountry.Clear();
                    tb_teamcity.Clear();
                }
            }
        }
        private void bt_addplayer_Click(object sender, EventArgs e)
        {
            if (tb_playername.Text == "" || tb_playernumber.Text == "" || cb_playerposition.SelectedItem == null)
            {
                MessageBox.Show("Tolong isi semua sebelum di add player");
            }
            else if (cb_team.SelectedItem == null || cb_country.SelectedItem == null)
            {
                MessageBox.Show("Tolong pilih terlebih dahulu team dan country");
            }
            else
            {
                bool ada = false;
                foreach (DataRow row in Team.Rows)
                {
                    if (row["Team"].ToString() == TeamYgDipilih && row["Nomor"].ToString() == tb_playernumber.Text)
                    {
                        ada = true;
                    }
                }
                if (ada == true)
                {
                    MessageBox.Show("Nomor sudah terpakai");
                }
                else
                {
                    listB_soccerteam.Items.Clear();
                    Team.Rows.Add(cb_country.Text, cb_team.Text, tb_playernumber.Text, tb_playername.Text, cb_playerposition.Text);
                }
                foreach (DataRow row in Team.Rows)
                {
                    if (TeamYgDipilih == row["Team"].ToString() && row["Nomor"].ToString() != "00")
                    {
                        string playerInfo = "(" + row["Nomor"].ToString() + ")  " + row["Nama"].ToString() + " - " + row["Posisi"].ToString();
                        listB_soccerteam.Items.Add(playerInfo);
                    }
                }
                tb_playername.Clear();
                tb_playernumber.Clear();
                cb_playerposition.SelectedItem = null;
            }
        }
    }
}
